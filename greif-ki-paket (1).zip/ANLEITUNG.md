# GREIF XPEDITION Krisenvorsorge-Assistent – Anleitung

So machst du aus dem GREIF-Wissen deinen eigenen KI-Berater. Drei Dateien gehören zusammen:

- **wissensbasis-kompakt.md** – das komprimierte Wissen (empfohlen, passt in fast jede KI-Umgebung)
- **wissensbasis.json** – der vollständige Volltext (für Umgebungen, die große Dateien verarbeiten)
- **projektanweisung.txt** – die fertige Verhaltensanweisung für die KI (einfach komplett einfügen)
- **STARTNACHRICHT.txt** – die kurze Nachricht für Variante 3 (normaler Chat)
- **systemprompt.md** – dieselbe Anweisung mit Erklärkopf (nur zum Nachlesen)

Du brauchst kein Programmierwissen. Wähle die Umgebung, die du nutzt:

## Variante 1: ChatGPT (eigener GPT)
1. Gehe zu "GPTs" → "Erstellen".
2. Füge unter "Anweisungen" den gesamten Text aus `projektanweisung.txt` ein.
3. Lade unter "Wissen" die Datei `wissensbasis-kompakt.md` hoch.
4. Gib dem GPT einen Namen (z. B. "GREIF Krisenberater") und speichere. Fertig. Du kannst ihn privat nutzen oder per Link teilen.

## Variante 2: Claude (Projekt)
1. Erstelle ein neues "Projekt".
2. Füge den gesamten Text aus `projektanweisung.txt` als "Projektanweisungen" ein.
3. Lade `wissensbasis-kompakt.md` in das Projektwissen hoch.
4. Stelle deine Fragen im Projekt. Fertig.

## Variante 3: Beliebige KI im normalen Chat (einmaliges Gespräch)
Wenn deine KI-Umgebung keine dauerhaften Projekte oder eigenen Assistenten kennt, geht es so. Wichtig: Im normalen Chat behandelt die KI angehängte Dateien als Material, nicht als Anweisung. Deshalb braucht es eine Startnachricht.
1. Beginne ein neues Gespräch.
2. Hänge genau zwei Dateien an: `projektanweisung.txt` und `wissensbasis-kompakt.md`. Hänge NICHT `ANLEITUNG.md`, `systemprompt.md` oder `wissensbasis.json` an. Die ersten beiden sind für Menschen, die dritte ist dieselbe Anweisung ein zweites Mal und verwirrt die KI.
3. Schreibe dazu den Text aus `STARTNACHRICHT.txt` als Nachricht und sende alles zusammen ab.
4. Die KI soll mit einem Satz bestätigen und die Zahl der Kapitel nennen. Bei den zwei Dateien sollten es 112 sein (102 Handbuch und 10 Buch). Nennt sie eine andere Zahl oder keine, ist die Wissensdatei nicht angekommen.
5. Dann stellst du deine Fragen. Die Anweisung gilt nur für dieses eine Gespräch, für ein neues Gespräch beginnst du wieder bei Schritt 1.
6. Kontrollfrage: "Welche Kapitel im Material behandeln Wasser? Nenne die Kennungen." Das Ergebnis zeigt, ob die KI wirklich aus der Datei antwortet.
Wenn die Umgebung keine Dateianhänge erlaubt, füge den Text beider Dateien stattdessen direkt in die Nachricht ein, bei Längenbegrenzung in mehreren Teilen.

## Variante 4: Lokale / offline KI
Wer eine lokale KI betreibt (z. B. über eine der gängigen Desktop-Anwendungen für Sprachmodelle), lädt `projektanweisung.txt` als System-Prompt und `wissensbasis-kompakt.md` als Wissensquelle. So läuft der Berater komplett offline auf dem eigenen Rechner.

---

**Wichtig:** Der Assistent ersetzt keine Rettungskräfte. Bei akuter Gefahr immer 112 wählen. Das Wissen hat den Stand November 2026; Preise, Gesetze und Technik können sich ändern. Aktuelles immer unter @greif_xpedition.

**Links in den Antworten:** Die Anweisung lässt den Berater auf die Webseite unter https://subvrsv.github.io/Greif-xpedition/ verlinken. Läuft das Material auf einer anderen Adresse, ersetze diese Basisadresse in `projektanweisung.txt` vor dem Einfügen.

**Link lässt sich nicht anklicken oder öffnet eine Suche (z. B. in Copilot):** Die Adresse steht als reiner Text in der Antwort. Kopiere sie in die Adresszeile deines Browsers.
