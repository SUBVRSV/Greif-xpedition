# GREIF XPEDITION – Wissensbasis für KI-Assistenten

Komprimiertes Wissen aus dem GREIF XPEDITION Krisenhandbuch (103 Kapitel, praktisches Wie) und dem Begleitbuch "Wenn es ernst wird" (10 Kapitel, erzählendes Warum). Jeder Eintrag nennt die Kapitel-ID für den Verweis (index.html#ID bzw. buch.html#ID).

Stand: November 2026. Quelle: @greif_xpedition

---

## TEIL A -- DAS BUCH (Hintergrund, das Warum)

### Die Nacht, in der die Hilfe nicht kam
*Warum kluge, normale Menschen anfangen, sich vorzubereiten, und warum das nichts mit Angst zu tun hat.* -- buch.html#kap-1

Um 11:17 Uhr rief das Landesumweltamt Rheinland-Pfalz für das Einzugsgebiet der Ahr die zweithöchste Warnstufe aus. Um 17:17 Uhr wurde in der Warn-App KATWARN die höchste Stufe erreicht, dargestellt in tiefem Violett: sehr große Hochwassergefahr.

### Die 72 Stunden, die über alles entscheiden
*Warum die ersten drei Tage anders sind als alles, was danach kommt, und warum kaum jemand das weiß.* -- buch.html#kap-2

September 2003 ganz Italien der Strom ausfiel, saßen dreißig Millionen Reisende, Nachtschwärmer und Schlafende plötzlich im Dunkeln. Es war ein Sonntagmorgen, kurz vor drei Uhr.

### Wasser
*Das selbstverständlichste Ding der Welt, bis es das erste ist, das fehlt.* -- buch.html#kap-3

Kein Krieg, keine Naturkatastrophe, nur ein Rohrbruch und eine notwendige Reparatur. Kein Krieg, keine Naturkatastrophe, nur ein Rohrbruch und eine notwendige Reparatur.

### Wenn das Licht ausgeht
*Warum ein Stromausfall nicht ein dunkles Zimmer ist, sondern der Moment, in dem man merkt, wie viel an einem einzigen Faden hängt.* -- buch.html#kap-4

August 2003, kurz nach vier Uhr nachmittags, war ein Baum in Ohio zu hoch gewachsen. Er berührte eine Hochspannungsleitung, die sich bei Last durchgehängt hatte.

### Vorrat, oder die Kunst, satt zu bleiben
*Warum ein guter Vorrat eher aussieht wie ein gut geführter Haushalt als wie ein Bunker.* -- buch.html#kap-5

Nicht das Mehl ging zuerst aus, nicht die Konserven, nicht das Wasser. Nicht das Mehl ging zuerst aus, nicht die Konserven, nicht das Wasser.

### Wärme, Licht und ein Dach
*Warum Kälte der leiseste aller Gegner ist und warum ausgerechnet der Versuch, sich zu wärmen, zur größten Gefahr werden kann.* -- buch.html#kap-6

Ein älterer Mann sitzt in seinem Sessel, das Radio läuft nicht mehr, die Heizung ist seit dem Vormittag aus. In der Wohnung sind es vielleicht vierzehn Grad, und sie sinken langsam weiter.

### Wenn die Netze schweigen
*Warum ein voller Akku im Ernstfall nichts nützt und die Sonne im Kopf trotzdem aufgehen kann.* -- buch.html#kap-7

Stell dir vor, es ist der zweite Tag eines großflächigen Stromausfalls. Dein Handy ist geladen, du hast sogar an die Powerbank gedacht.

### Die anderen
*Warum das Bild vom Krieg aller gegen alle ein Mythos ist und der beste Vorrat der ist, den man teilen kann.* -- buch.html#kap-8

Fragt man Menschen, was in einer echten Krise mit der Gesellschaft passiert, bekommt man fast immer dieselbe Antwort. Man kennt die Bilder aus Filmen: leergeräumte Supermärkte, brennende Autos, Menschen, die sich um die letzte Dose prügeln.

Zur Einordnung: Die Befunde zu Desaster-Mythen gelten für gemeinsam erlittene Notlagen. Unruhen wie in Frankreich im Oktober 2026 sind ein sozialer Konflikt, in dem Teile einer Menge bewusst Gewalt ausüben. Beides gibt es, man sollte es nicht vermischen (siehe index.html#unruhen-ausschreitungen).

### Das Undenkbare denken
*Über das Szenario, das niemand gern ausspricht, und warum ausgerechnet die ruhigsten Länder der Welt es am nüchternsten behandeln.* -- buch.html#kap-9

Auf dem Titel stand: „Om krisen eller kriget kommer.“ Wenn die Krise oder der Krieg kommt. Auf dem Titel stand: „Om krisen eller kriget kommer.“ Wenn die Krise oder der Krieg kommt.

### Danach
*Warum das Überstehen nicht das Ende ist, sondern der Anfang von etwas, das man Weiterleben nennt.* -- buch.html#kap-10

Als das Wasser im Ahrtal zurückwich, blieb etwas zurück, das auf keiner Schadensliste stand. Die Häuser konnte man trocknen, die Straßen wieder aufbauen, die Brücken neu bauen.

---

## TEIL B -- DAS HANDBUCH (Praxis, das Wie)

### cover
index.html#cover

Überlebensdokument // @greif_xpedition SURVIVAL & KRISENVORSORGE GREIF XPEDITION Krisenhandbuch Wahrscheinlich das umfangreichste kostenlose deutschsprachige Handbuch zu Survival & Krisenvorsorge.
- Kein Sponsoring, keine Paywall, kein Affiliate-Link.
- Gefahr einschätzen: Bin ich in unmittelbarer Gefahr? Wenn ja: raus. Wenn nein: Ruhe bewahren.
- Familie/Mitbewohner zusammenrufen. Alle am selben Ort. Niemand alleine lassen.
- NINA oder KATWARN öffnen. Offizielle Informationen abwarten bevor man handelt.
- Bleiben oder verlassen? Bleiben ist in den meisten Szenarien sicherer. Nur bei unmittelbarer Gefahr (Feuer, Flut, Evakuierungsbefehl) verlassen.

### Inhalt
*Survival & Krisenvorsorge. Praxisleitfaden // @greif_xpedition* -- index.html#inhalt

Praxisleitfaden // @greif_xpedition Level 1.
- Vertieft & Langzeit ▶ Alltag in der Krise ▶ Wissen & Hintergrund ▶ Anhang & Tools ▶
- Bug-Out-Bag : Fluchtrucksack · Packliste · Gewicht
- Chest Pack : Ergänzung zum BOB · Schnellzugriff
- Kleidung & Ausrüstung : Marken · Schichtprinzip · Kriterien
- Tools & Hacks : Unter 30 EUR · maximaler Nutzen

### L1 // Standard-Rucksack: 72 Stunden
*Eine Liste · 27 Posten · nach BBK · zum Abhaken* -- index.html#standard-rucksack

- Einstiegsliste für Neulinge: ein fertiger Rucksack für etwa 72 Stunden in Notunterkunft oder bei Verwandten, nach der Notgepäck-Empfehlung des BBK (Merkblatt MVE05), ergänzt um fünf Kleinteile. Vertiefung im Kapitel Bug-Out-Bag.
- BBK-Posten: Rucksack, Wasserflasche, Verpflegung für zwei Tage (staubdicht), Essgeschirr, Besteck, Dosenöffner, Taschenlampe und Radio mit Ersatzbatterien, Schlafsack oder Decke, gegebenenfalls Isomatte, Kleidung für ein paar Tage, Wetterschutz, feste Schuhe, Kopfbedeckung, Arbeitshandschuhe, Atemschutz, persönliche Medikamente, Erste-Hilfe-Material, Hygieneartikel, Dokumentenmappe wasserdicht, Taschenmesser.
- Laut Stiftung Warentest (05.02.2026) zusätzlich: Powerbank, Notizblock und Stift, Feuerzeug, Ersatzbrille. GREIF-Zusätze: kleiner Wasserfilter, Rettungsdecken, Trillerpfeife, große Müllbeutel.
- Richtwerte aus den Handbuch-Tabellen (Stand September 2026): die 15 bepreisten Posten kosten zusammen etwa 244 bis 509 Euro und wiegen rund 4,22 bis 4,72 kg, ohne Rucksack, Kleidung, Radio und Hygiene. Das BBK nennt kein Höchstgewicht, nur: ohne fremde Hilfe längere Zeit tragbar.
- Erst im letzten Moment greifen: Ausweis, Bargeld und Karten, Gesundheitskarte, Impfpass, Schlüssel, Handy. Kleinkinder: Brustbeutel oder SOS-Kapsel mit Name, Geburtsdatum, Anschrift. Ein Rucksack pro Person.
- Fehler: fertig gekaufte Notfallrucksäcke ungeprüft übernehmen (Warentest empfiehlt keinen), zu schwer packen, nach dem Packen nie wieder prüfen. Zweimal im Jahr kontrollieren.

### L1 // Bug-Out-Bag
*Fluchtrucksack: 72h bis 2 Wochen / 1 Person* -- index.html#bug-out-bag

Ziel: Innerhalb von 5 Minuten griff- und abmarschbereit.

### L1 // Chest Pack
*Helikon-Tex Chest Pack // Always-On-Ausrüstung* -- index.html#chest-pack

Sie wird körpernah auf der Brust getragen und enthält ausschließlich Gegenstände, die im Notfall sofort ohne Ablegen des Rucksacks erreichbar sein müssen.
- Der Chest Pack wird IMMER getragen, auch ohne BOB.
- Inhalt = sofortiger Zugriff ohne jede Verzögerung.
- Beim Ablegen des BOB: Chest Pack verbleibt am Körper.
- Regelmäßig auf Vollständigkeit prüfen, vor jedem Ausgang kontrollieren.

### L1 // Kleidung & Ausrüstung
*Empfohlene Kleidung & Marken für den Einsatz* -- index.html#kleidung-ausruestung

Einsatztaugliche Kleidung muss funktional, robust und wetterbeständig sein.
- Die folgenden Empfehlungen basieren auf persönlicher Erfahrung und realen Einsätzen.

### L1 // Tools & Hacks
*Fast umsonst, maximaler Nutzen · Unter 30 EUR* -- index.html#tools-hacks

Manche der nützlichsten Hilfsmittel kosten weniger als ein Kaffee, und können im Ernstfall entscheidend sein.
- nina.bund.de : Warn-App des Bundes, auch als Webseite. Aktuelle Warnungen Deutschland.
- dwd.de : Deutscher Wetterdienst. Unwetterwarnungen, Sturmverlauf.
- animatedknots.com : Alle Knoten animiert Schritt für Schritt, kostenlos.
- nabu.de/pflanzen : Pflanzenporträts mit echten Fotos, Deutschland.

### L1 // Flüssigkeiten & Kompaktsysteme
*Öle. Chemikalien. Hygiene. Alles was sich abfüllen, komprimieren und transportieren lässt.* -- index.html#fluessigkeiten-bob

Eine 500ml-Flasche Ballistol passt nicht in den Chest Pack, eine Literflasche Bleiche schon gar nicht.
- Nicht mischen was sich nicht verträgt: Bleiche und Isopropanol nie im selben Beutel. Bleiche und Ammoniak (in manchen Reinigern) reagieren zu giftigen Chlorgasen. DEET nicht neben ...
- Flüssigkeiten-Beutel im BOB: Einen eigenen Ziplock-Beutel (2L) für alle Flüssigkeiten anlegen. Dieser Beutel ist der Auffangbehälter wenn etwas ausläuft. Nicht verteilen im Rucksac...
- Dichtheit testen vor dem ersten Einsatz: Jede befüllte Flasche 24h umgekehrt in einem Beutel lagern. Was ausläuft, wird ersetzt oder besser verschlossen. Kein Test = böse Überrasch...
- Verfallsdaten beachten: Bleiche verliert nach 6–12 Monaten an Wirksamkeit. DEET: 2–3 Jahre. Sonnenschutz: 1–2 Jahre nach Öffnung. Alle 6 Monate den Flüssigkeiten-Beutel öffnen, prü...

### Nahrung // Konzept & Einführung
*Einsatzzweck · Szenarien · Level-System* -- index.html#nahrung-konzept

Unabhängig von Supermärkten, Lieferketten und Strom.
- Alle Produkte sind mindestens 1–3 Jahre haltbar
- Keine Kühlkette erforderlich
- Minimaler Kochaufwand, funktioniert mit Gas-, Hobo- oder Esbitkocher
- Kalorisch ausreichend: ca. 1.900 kcal/Tag

### Nahrung // 28-Tage Essensplan
*Vollständiger Tagesplan für 1 Person* -- index.html#essensplan

Alle Mahlzeiten funktionieren ohne Kühlung und mit minimalem Kochaufwand.

### Nahrung // Einkaufsliste
*Vollständige Beschaffungsliste: 1 Person / 4 Wochen* -- index.html#einkaufsliste

Alle Produkte sind in normalen Supermärkten erhältlich, lange haltbar und ohne Kühlung lagerbar.

### Nahrung // Lagerung & Haltbarkeit
*Optimale Aufbewahrung für maximale Haltbarkeit* -- index.html#nahrung-lagerung

Falsch gelagertes Essen verdirbt, auch wenn es teuer war.
- Die Feinde sind immer dieselben: Feuchtigkeit, Wärme, Licht, Sauerstoff und Schädlinge.
- FIFO-Prinzip: First In. First Out. Ältestes immer vorne.
- Temperatur: 10–18°C ideal. Über 25°C reduziert Haltbarkeit erheblich.
- Dunkel: Lichteinfall beschleunigt Verderb. Geschlossene Kisten bevorzugen.
- Trocken: Luftfeuchtigkeit unter 60% halten. Feuchte zerstört Trockenware.

### Nahrung // Kochen & Feldküche
*Feldküche ohne Infrastruktur* -- index.html#feldkueche

Dieses Kapitel zeigt welche Ausrüstung nötig ist, welche Methoden funktionieren und worauf man besonders achten muss.
- Hobokocher (Holz/Biomasse) ODER Esbitkocher + Tabletten, mindestens eine Option sicherstellen. Optional: Gaskocher (mini) + Kartuschen als schnelles Primärsystem.
- 1 kleiner Topf (Titan-Set reicht für 1 Person, für 2+ Personen optional einen Falttopf ergänzen, z.B. Sea to Summit X-Pot 1,4–4L, faltbar, kaum Platz)
- Hitzefeste Tasse / Schüssel
- Dosenöffner (KRITISCH: immer dabei): auch Mini-Dosenöffner (z.B. P38/P51 Armeedosenöffner, ca. 1 EUR) oder Taschenmesser mit integriertem Dosenöffner (Victorinox) sind ausreichend

### Nahrung // Kalorien & Nährstoffe
*Orientierungswerte für 1 Person / Tag* -- index.html#nahrung-naehrstoffe

Wer das nicht versteht, plant falsch: zu wenig und man verliert Kraft, zu viel und Vorräte werden verschwendet.
- Fett liefert die meiste Energie pro Gramm, wird aber fast immer zu wenig bevorratet.

### L2 // Medizin & Erste Hilfe
*Erste Hilfe · Langzeitgesundheit · Notfallversorgung* -- index.html#medizin-erstehilfe

| Starke Blutungen stoppen | ★★★ KRITISCH Tourniquet (CAT / SOFTT-W) [6] | 1 Stk.
- | Extremitätenblutung stoppen | ★★★ KRITISCH Wundspüllösung (NaCl 0,9%) | 2x 250ml | Wunden reinigen | ★★★ KRITISCH Verbandsmull / Kompressen | 10 Stk.
- 1. Blutung stoppen: Direktdruck mit Kompresse, bei starker Blutung Druckverband oder Tourniquet (Extremitäten).
- 2. Wunde reinigen: Mit NaCl-Lösung spülen, Fremdkörper entfernen, niemals Jod in offene Wunden.
- 3. Desinfizieren: Octenisept oder Betaisodona auf Wundrand, nicht in die Tiefe.
- 4. Verschließen: Steri-Strips bei klaffenden Wunden. Mull-Kompresse + Pflaster bei kleineren.

### L2 // Medikamente & chronische Erkrankungen
*Vorrat aufbauen. Haltbarkeit kennen. Alternativen kennen.* -- index.html#medikamente-vorrat

Insulin, Blutdrucktabletten, Schilddrüsenhormone, Antidepressiva, Antikoagulantien -- diese Medikamente können nicht einfach durch Vorräte aus dem Supermarkt ersetzt werden.
- Reisevorrat nutzen: Vor Auslandsreisen wird oft ein Zusatzvorrat verschrieben. Jährliche Reise einplanen und Medikamente mitnehmen.
- Privatrezept: Für viele Standardmedikamente möglich. Kostet mehr, aber legal und ohne Diskussion.
- Rotation: Älteste Packung nehmen, neue einlagern. Vorrat bleibt immer frisch. Kein Medikament verfällt.
- Ziel: 90 Tage. 3 Monate sind realistisch erreichbar und decken die meisten Krisenszenarien ab. 6 Monate für Hochrisiko-Medikamente (Insulin, Immunsuppressiva).

### L3 // Medizin ohne Arzt
*Wunden nähen. Knochen schienen. Zahn. Fieber. Antibiotika-Alternativen.* -- index.html#medizin-ohne-arzt

Alle beschriebenen Maßnahmen sind Notfalllösungen wenn kein Arzt erreichbar ist.
- Wann nähen: Nur bei klaffenden Wunden die durch Streifen nicht geschlossen werden können. Nie bei infizierten Wunden, Bisswunden oder Wunden älter als 6 Stunden.
- Material sterilisieren: Nadel und Faden 10 Minuten in kochendem Wasser oder mit Feuer erhitzen und abkühlen lassen. Hände mit Alkohol desinfizieren. Einmalhandschuhe wenn vorhanden...
- Einfacher Einzelknopfstich: Nadel 5–8 mm neben dem Wundrand einstechen, durch die Wunde führen, auf gleicher Höhe gegenüber herausstechen. Faden verknoten. Abstand zwischen Stichen...
- Wundnahtsets: Fertige Wundnahtsets (z.B. von Emergency Medical Kit) enthalten Nadel, Faden, Anleitung. Im IFAK lagern. Kosten 10–20 EUR.

### L2 // Hygiene & Sanitär
*Wenn kein fließendes Wasser verfügbar ist* -- index.html#hygiene-sanitaer

Fehlende Hygiene führt schnell zu Infektionen, Hautproblemen und Durchfallerkrankungen, die die Handlungsfähigkeit massiv einschränken.
- Option 1. Feldtoilette: Loch 20–30 cm tief graben, mind. 60 m von Wasserquellen entfernt. Mit Erde abdecken.
- Option 2. Falttoilette: Stabiler Rahmen, spezielle Hygienebeutel mit Gelkissen, geruchsarm, transportierbar.
- Option 3. Eimer-System: 20L-Eimer mit Deckel + Toilettensitz-Aufsatz + Hygienebeutel. Günstig und effektiv.
- Feuchttücher für Ganzkörper-Abreibung. Reihenfolge: Gesicht, Hände, Körper, Intimbereich.

### L2 // Haushaltschemie als Ressource
*Bleiche. Alkohol. Seife. Was normale Produkte im Krisenfall leisten.* -- index.html#haushalts-ressourcen

Wer versteht was die Chemie dahinter leistet, kann mit wenig Mitteln viel erreichen.
- Isopropanol 70% (Isopropylalkohol): Effektivste und günstigste Desinfektionslösung. 70% ist wirksamer als 99% (Wasser hilft beim Eindringen in Zellen). Für Wunden, Hände, Instrumen...
- Hochprozentiger Trinkalkohol (ab 60%): Notfalloption wenn kein Isopropanol vorhanden. Brennt stärker in Wunden. Nicht als Anästhesie: zu geringe Wirkung, zu viel Schaden.
- Als Brennstoff: Alkohol ab 90% brennt. In Hobokocher oder Spirituskocher nutzbar. Sauber, rußfrei, in Innenräumen mit Belüftung verwendbar.
- Tauschware: Hochprozentiger Alkohol ist in einer Mangelwirtschaft harte Währung. Auch als Schmerzmittel oder Schlafmittel gefragt (nicht empfohlen, aber Realität).

### L2 // Kommunikation
*Informiert bleiben und erreichbar sein wenn Strom und Internet ausfallen* -- index.html#kommunikation-krise

Wer dann noch kommunizieren kann, hat einen entscheidenden Vorteil: Lagebeurteilung, Familienkoordination, Entscheidungsgrundlage.
- Internationales Notsignal: SOS in Morsecode: drei kurz, drei lang, drei kurz. Mit Taschenlampe, Spiegel, Pfeife oder Klopfen. Jeder Retter kennt es.
- Pfeife: Drei Pfiffe = Notsignal. Trägt weiter als Schreien, kostet keine Energie. Im BOB und Chest Pack.
- Signalspiegel: Reflexionsspiegel kann Flugzeuge auf 50+ km aufmerksam machen. Billig, leicht, wartungsfrei. Technik üben.
- Rauchsignal: Tagsüber dunkler Rauch (Gummi, Plastik) sichtbar gegen Himmel. Nachts helles Feuer. International: drei Feuer im Dreieck = Notlage.

### L2 // Navigation
*Karte, Kompass, Routen. Wenn GPS ausfällt.* -- index.html#navigation-krise

Wer keine analogen Navigationsfähigkeiten hat, ist in einer Krise geografisch blind.
- Karte einorden: Karte flach hinlegen. Kompass auf Karte. Karte drehen bis Nordnadel mit Kartennorden übereinstimmt. Jetzt zeigt die Karte in die richtige Richtung.
- Peilung abnehmen: Kompass auf Karte legen, Kante entlang der gewünschten Route ausrichten. Gehäuse drehen bis Nordmarkierung mit Nordnadel übereinstimmt. Abgelesener Winkel = Marsc...
- Marschieren: Kompass vor dem Körper halten, Nordnadel in Nordmarkierung halten. In Richtung des Reisepfeils laufen. Alle 100–200 m kontrollieren.
- Deklination: Magnetischer und geografischer Nordpol weichen ab. In Deutschland ca. 2–4° Ost. Für kurze Distanzen vernachlässigbar, bei langen Märschen korrigieren.

### L2 // Energie & Strom
*Stromversorgung im Langzeitausfall* -- index.html#energie-strom

Kommunikation, Licht, Medizin, Information, alles hängt direkt oder indirekt davon ab.
- Ebene 1. Pocket: Powerbanks am Körper (Chest Pack + BOB). Klein, immer dabei, für Handy / Funk / Licht.
- Ebene 2. Tragbar: Kleiner Solargenerator ca. 750 Wh + 1–2 faltbare Solarpanels à 160W. Läuft völlig autark. Transport in der Hand oder im Bollerwagen, nicht im Rucksack (zu schwer,...
- Ebene 3. Fahrzeug: Große Powerstation 2–3 kWh, ca. 20–28 kg. Ausschließlich per Auto oder Bollerwagen, nicht von Hand tragbar. Liefert genug Strom für alle mobilen Geräte über Tage...
- Völlig autarker Betrieb, kein Setup, einfach einschalten und nutzen. Kein Lärm, keine Abgase, keine Genehmigung nötig.

### L2 // Technik im Feld
index.html#technik-field

Uhren, Optik, Kommunikation, Beobachtung Felduhren Optik & Beobachtung Smartphone & Apps Audio & Zubehör Technik im Einsatz ist Werkzeug, kein Selbstzweck.
- Jedes Gertät muss einen konkreten Vorteil bringen, robust genug sein um Regen, Staub und Sturz zu überstehen, und darf keine kritische Abhängigkeit schaffen.

### L2 // Finanzen & Dokumente
*Wenn Banken, Karten und Netze ausfallen* -- index.html#finanzen-dokumente

Wer hier nicht vorbereitet ist, kann selbst bei ausreichend Vorräten handlungsunfähig werden.
- Gesamtbetrag: Mindestens 500–1.000 EUR in bar zuhause. Bei längerer Krise mehr.
- Stückelung: Viele kleine Scheine: 5, 10, 20 EUR. Wechselgeld ist kritisch wenn niemand herausgeben kann.
- Aufteilen: Nie alles an einem Ort. Zuhause / BOB / Chest Pack / separates Versteck.
- Fremdwährung: USD oder CHF als Reserve, bei langer Krise könnte EUR an Wert verlieren.

### L2 // Finanzkrise & Bankensystem
*Kapitalverkehrskontrollen · Einlagensicherung · Bargeld · Edelmetalle* -- index.html#finanzkrise

Beides kann parallel auftreten, beides erfordert Vorbereitung.

### L2 // Digitale Vorbereitung
*Dokumente sichern. Passwörter. Was offline muss bevor es zu spät ist.* -- index.html#digitale-vorbereitung

Und wenn du fliehen musst, braucht du deine Dokumente ohne Internetzugang.
- VeraCrypt (kostenlos, Open Source): Erstellt verschlüsselte Container auf dem USB-Stick. Ohne Passwort kein Zugang. Auf Windows, Mac und Linux verfügbar. Einrichtung: ca. 30 Minute...
- Alternative 7-Zip: Dokumente in ein passwortgeschütztes Archiv packen. Weniger sicher als VeraCrypt, aber einfacher. Für grundlegenden Schutz ausreichend.
- Passwort notieren: Das Verschlüsselungspasswort handschriftlich auf Papier, separat vom USB-Stick aufbewahren. Tresor, Bank, oder bei einer Vertrauensperson. Passwort vergessen = D...
- Zwei Kopien: USB-Stick zuhause im Dokumentenordner + zweite Kopie bei Vertrauensperson oder im Bankschließfach. Brandschutz, Diebstahlschutz.

### L2 // Soziales Netzwerk & Nachbarschaft
*Der unterschätzteste Faktor in der Krisenvorsorge* -- index.html#soziales-netzwerk

Historisch und statistisch ist das eindeutig belegt.
- Aufgabenteilung: Niemand kann alleine wachen, kochen, schlafen und Lage beobachten gleichzeitig.
- Komplementäre Fähigkeiten: Arzt, Elektriker, Landwirt, Mechaniker. Wissen ist mehr wert als Ausrüstung.
- Psychologische Stabilität: Isolation ist einer der stärksten Stressfaktoren in Langzeitkrisen.
- Ressourcenteilung: Geteilte Vorräte, geteiltes Wissen, geteilte Last.

### L2 // Werkzeug-Grundausstattung
*Was zuhause vorhanden sein muss um in einer Krise reparieren, bauen und improvisieren zu können* -- index.html#werkzeug-zuhause

Werkzeug ist in einer Krise Infrastruktur.
- Wer reparieren, improvisieren und bauen kann, ist weit weniger abhängig von Lieferketten und Dienstleistern.
- Hauptwasserabsperrung kennen: Wo ist der Haupthahn? Im Keller, unter der Spüle, im Technikraum. Jetzt lokalisieren, nicht erst wenn Wasser läuft. Einmal drehen prüfen ob er sich no...
- Rohrzange vorhanden: Für Siphons, Anschlüsse und Absperrventile. Knipex Cobra 250mm ist Universalwerkzeug für fast alle Rohrdurchmesser.
- Dichtungsband (PTFE): Weißes Teflonband für Gewindeverbindungen. Kosten unter 2 EUR, rettet undichte Verbindungen in Minuten. Immer vorrätig.
- Rohrschellen und Dichtmanschetten: Provisorische Abdichtung bei Rohrbruch. Drückt über das Leck und gibt Zeit für richtige Reparatur. Im Baumarkt 3–8 EUR.

### L3 // Wasservorrat
*Stationäre Wasserbevorratung, das wichtigste Gut* -- index.html#wasservorrat

Die Wasserversorgung ist gleichzeitig eine der verwundbarsten Infrastrukturen im Krisenfall.
- Behälter: Nur lebensmittelechte Kunststoffe (HDPE, Kennzeichnung "Lebensmittelgeeignet") oder Edelstahl. Kein normales PET über längere Zeit.
- Standort: Kühl, dunkel, frostsicher. Keller ideal. Kein direktes Sonnenlicht (fördert Algenwachstum).
- Haltbarkeit: Leitungswasser in geschlossenen HDPE-Behältern ca. 6–12 Monate [13] . Danach filtern oder tauschen.
- Konservierung: Pro 10 Liter 1–2 Tropfen unparfümierte Haushaltsbleiche (Natriumhypochlorit 5%, ohne Duft- und Zusatzstoffe): verlängert Haltbarkeit auf 1–2 Jahre.

### L3 // Fahrzeug
*Das Fahrzeug als mobiles Evakuierungssystem* -- index.html#fahrzeug-krise

Nicht mehr: Hitze im Auto baut Plastikflaschen schnell ab.
- Tankregel: Tank nie unter halbe Füllung sinken lassen. Im Krisenfall sind Tankstellen die ersten Orte die überfüllt oder leer sind.
- Reservekanister: 10–20 Liter Reservekraftstoff sicher gelagert. Metallkanister, kühl und dunkel, alle 6 Monate tauschen.
- Wartungsstand: Ölstand, Reifendruck, Batterie, Kühlwasser regelmäßig prüfen. Kein Krisenstart mit abgelaufenen Reifen.
- Dokumente im Fahrzeug: Fahrzeugschein, Versicherungsnachweis, Pannenhilfe-Nummer, immer dabei.

### Langzeit // Mobile Krisenvorsorge
*Fahrzeuge, Anhänger, Fahrräder. Realistisch. Ohne Wohnmobil für 150.000 EUR.* -- index.html#mobilitaet-krise

Mobile Krisenvorsorge ist kein Pflichtthema des Handbuchs.
- Packraft als Krisenboot: z.B. Anfibio oder Alpacka Raft -- aufblasbar, passt in den Rucksack (2-3 kg), hält 150 kg, aus Hypalon oder TPU. Kostet 500-1.500 EUR. Die flexibelste Wass...
- Wasserweg planen: Jetzt, nicht in der Krise: Flüsse, Kanäle, Seen in 50 km Radius auf Karte einzeichnen (OSMAnd offline). Welche führen wohin? Wo sind Stellen die man umtragen muss...
- Grundausstattung: Schwimmweste (immer!), Paddel, Reparaturset (Flicken + Kleber), wasserdichte Packsäcke für Gepäck, Wurfwurst (10m Leine), Neopren oder Trockenanzug bei kaltem Was...
- Rechtslage Deutschland: Auf Bundeswasserstraßen ist Paddeln grundsätzlich erlaubt (mit Einschränkungen). Naturschutzgebiete und Vogelschutz beachten. In Krisen gelten diese Regeln ...

### L3 // Shelter & Evakuierung
*Bleiben oder gehen. Shelter-in-Place. Feldunterkunft.* -- index.html#shelter-evakuierung

Diese Entscheidung muss VOR der Krise durchdacht werden.
- Raum verkleinern: Einen Raum wählen, alle anderen schließen. Kleinerer Raum = weniger Wärmeverlust. Körperwärme reicht für kleine Räume.
- Fenster isolieren: Baufolie mit Klebeband über Fensterrahmen kleben. Zweite Schicht mit Luftpolster dazwischen verdoppelt die Dämmung.
- Türritzen abdichten: Handtücher oder Zugluftstopper unter Türen. Kalte Luft kommt meist durch Ritzen, nicht durch Wände.
- Schichten tragen: Mehrere dünne Schichten wärmen besser als eine dicke. Merinowolle als Basisschicht. Kopf bedeckt halten.

### L3 // Extremwetter unterwegs. Mit dem BOB durch Gewitter, Sturm, Kälte, Hitze.
*Wenn das Wetter dreht und kein Gebäude in Reichweite ist.* -- index.html#extremwetter-unterwegs

Kein Gebäude, kein Auto, keine Rückzugsoption in unter 30 Minuten.
- Die Regeln hier sind für genau diese Lage.
- Sofort verlassen: Gipfel, Grate, Bergkämme, offene Felder, Waldränder, einzeln stehende Bäume, Gewässerufer. Auch: Metallzäune, Weidezäune, Stahlseile von Klettersteigen (mehrere M...
- Aufsuchen: Bodenmulden, dichter Wald (Lichtung oder Schonung im Inneren, nicht der Rand), tiefste Stelle im Gelände. Ein Auto mit Metallkarosserie ist ein Faradayscher Käfig und sc...
- Schutzposition: In die Hocke, Füße geschlossen (Schrittspannung!), Arme um die Knie, Kopf runter. Nicht flach hinlegen, das vergrößert die Kontaktfläche für Bodenströme. Auf den Ru...
- Gruppe: Mindestens 1 Meter, besser 3 Meter Abstand zueinander, auch zu Kindern. Ein Blitz der eine Person trifft, soll nicht per Überschlag die ganze Gruppe treffen.

### Urban // Wohnen im Krisenfall
*Mietwohnung. Mehrfamilienhaus. Kein Keller. Kein Garten. Trotzdem vorbereitet.* -- index.html#urban-wohnen

Krisenvorsorge wird fast immer für Hausbesitzer gedacht: Keller, Garten, Werkstatt, eigene Wasserversorgung.
- Die Realität in Deutschland ist eine andere.

### Urban // Mietwohnung. Konkret.
*80 Prozent der Deutschen wohnen in Städten. Dieses Kapitel ist für sie.* -- index.html#urban-mietwohnung

Wer in einer Mietwohnung im Mehrfamilienhaus wohnt, kein Auto hat, keinen Garten und kaum Abstellraum, braucht andere Antworten.
- Treppenhaus bei Dunkelheit: Wer seine Treppe nicht auswendig kennt, sollte sie heute mit geschlossenen Augen üben: wie viele Stufen, wo ist das Geländer, wo sind die Absätze. Das k...
- Nordbalkon: Weniger Direktsonne, aber diffuses Licht reicht für 30-50% der Nennleistung. Kein Grund auf Solarversorgung zu verzichten.
- Kein Balkon: Fensterbrett-Panel (kleine Einheit, nach außen gestellt) oder Panel am Dachrand wenn Zugang möglich. Sonst: ausreichend Powerbanks und Ersatzbatterien bevorraten.
- Kühlschrank: Im Blackout nicht öffnen. Hält 4-6 Stunden Temperatur wenn geschlossen. Tiefkühler 12-24 Stunden. Danach sofort verarbeiten und essen was verderblich ist.

### Urban // Wohnung & Haus absichern
*Türen. Fenster. ABC-Schutz. Verdunkelung. Was wirklich hält.* -- index.html#wohnung-absichern

Sie muss mehrere Funktionen gleichzeitig erfüllen: Schutz vor Menschen, Schutz vor Witterung, Schutz vor Kontamination, und Unsichtbarkeit nach außen.
- Türstopper Metall: Unter die Tür schieben, kein Bohren. Hält auch wenn Schloss geknackt ist. Stanley FatMax oder vergleichbar, 15–25 EUR. Mehrere kaufen: Wohnungstür, Schlafzimmert...
- Türrahmen-Verstärkung: Die meisten Türrahmen geben beim ersten Tritt nach. Lange Schrauben (10cm+) in den Tragbalken hinter dem Rahmen: gibt der Tür echten Halt. Im Eigenheim einfa...
- Was nichts bringt: Teures Schloss ohne verstärkten Rahmen. Standard-Türkette (reißt beim ersten Ruck). Beschriftung am Briefkasten. Licht das immer zur gleichen Zeit an geht.
- Sofortmaßnahme: Alle Fenster und Türen schließen. Radio an. Kellerräume meiden: Gase sinken ab. Innenzimmer höherer Stockwerke sind sicherer als EG oder Keller.

### L3.06 // Sicherheit & Lager
*OPSEC · Perimeter · Fluchtrouten · Lagerstandort* -- index.html#sicherheit-lager

Sicherheit & Schutz Fluchtrouten Lagerstandort L3.06 // Sicherheit & Schutz Haus, Auto, Lager, Aufenthalt.
- Prävention vor Übergriffen In einer schweren Krise verändert sich das soziale Gefüge.
- Sichtbarkeit reduzieren: Keine Ware offen ins Haus tragen. Große Einkäufe in neutralen Taschen transportieren. Kein sichtbarer Vorrat im Fensterbereich.
- Nicht reden: Nicht mit Nachbarn, Bekannten oder in sozialen Medien über Vorräte oder Ausrüstung sprechen, auch nicht im Nachhinein.
- Normalität zeigen: Im Krisenfall nach außen hin so wirken als wäre man genauso betroffen wie alle anderen. Keine gut bestückte Wohnung zeigen.
- Licht kontrollieren: Nachts Licht abdunkeln, erleuchtete Fenster in einer dunklen Straße signalisieren Strom und damit Ressourcen.

### SV.01 // Selbstverteidigung
*Prävention · Ausrüstung · Technik · Ausbildung* -- index.html#selbstverteidigung

OPSEC | Niemand weiß was du hast | Kein Wissen = kein Angriffsziel 2.
- Im Gelb bleiben: Rücken zur Wand sitzen. Eingänge kennen. Wer schaut komisch? Wer bewegt sich gegen den Strom? Ohne Paranoia, einfach wach sein.
- Bauchgefühl: Gavin de Becker ("The Gift of Fear"): Wenn sich etwas falsch anfühlt, ist es falsch. Intuition ist Musterextraktion aus jahrtausenden Erfahrung, ernst nehmen.
- Körpersprache lesen: Zielgerichteter Blick auf Tasche/Gürtel, unnatürliche Gangart, Hände versteckt, zu viel Augenkontakt oder keiner, potenzielle Warnsignale.
- Stimme: Ruhig, tief, klar. Keine Schreie, keine Befehle. "Ich suche keinen Streit" ist mächtiger als Drohungen.

### L3 // Freiverkäufliche Mittel in DACH
*Rechtlicher Rahmen · Was sinnvoll ist · Was nicht · Notwehr* -- index.html#freie-waffen

Die meisten Krisenszenarien in DACH erfordern keine Waffe.
- Prävention, Ausweichen und Deeskalation sind fast immer die bessere Wahl.
- Lagebeurteilung vor Bedrohung: Wer Gefahren früh erkennt, muss ihnen nicht begegnen. Tiere-Frühwarnung, Gefahrenerkennung, OPSEC -- das sind die effektivsten Schutzmaßnahmen.
- Netzwerk: Gemeinschaft schützt. Alleinstehende sind gefährdeter als Gruppen. Bekannte Gesichter im Kiez, Nachbarschaft die zusammenhält -- das ist mehr Schutz als jedes freiverkäuf...
- Sichtbarkeit reduzieren: Wer nicht zeigt was er hat (Vorräte, Ressourcen), ist kein Ziel. OPSEC ist Prävention.
- Rückzug vor Konfrontation: In 99% aller realen Krisenszenarien in DACH ist Ausweichen die beste Option. Konfrontation eskaliert. Verletzungen -- auch bei "Siegern" -- können in ein...

### L3 // Wildnis & Bushcraft
*Wildpflanzen · Jagd & Fischen · Feuer · Knoten · Werkzeug · Wasser · Navigation* -- index.html#wildnis-bushcraft

ÜBEN VOR DER KRISE: Wildpflanzen lernt man am besten bei einem geführten Kurs oder mit einem gedruckten Feldführer direkt in der Natur.
- Angelschein empfohlen: Fischereiprüfung ist einfach (Online-Kurs, ca. 30–50 EUR) und öffnet legal eine wertvolle Nahrungsquelle.
- Notangel: Starke Schnur (Paracord-Kern) + Haken (aus Büroklammer biegen) + Köder (Regenwurm, Insekten) + Stock. Funktioniert für Friedfische.
- Beste Köder aus der Natur: Regenwürmer (nach Regen), Heuschrecken, Maden, Teigbälle aus Brot und Wasser.
- PET-Flasche Fischreuse: 2L-Flasche in der Mitte aufschneiden, oberen Teil umkehren und einstecken, primitive Fischfalle für Kleinfische.

### L3 // Tiere als Frühwarnsystem
*Vogelverhalten · Hundeinstinkt · Insekten · Was die Natur signalisiert* -- index.html#tiere-fruehwarnung

Geruch, Vibration, Infraschall, elektromagnetische Felder: Tiersinne erfassen Signale die für Menschen unsichtbar sind.
- Nasenleistung: Hunde riechen ca. 1.000-mal besser als Menschen. Sie erkennen Fremde, Tiere und Chemikalien auf hunderte Meter. Ein Hund am Lager ist kein Komfortfaktor, sondern ein...
- Knurren ohne Ursache: Wenn ein Hund knurrt oder aufmerksam starrt ohne sichtbaren Grund: etwas ist außerhalb der menschlichen Wahrnehmung. Richtung beachten, Situation prüfen.
- Haare sträuben (Piloerection): Haare im Nacken stehen auf: Hund nimmt unmittelbare Bedrohung wahr. Stärker als Knurren. Sofort reagieren.
- Verhaltenswechsel vor Naturereignissen: Hunde zeigen Verhaltensänderungen Stunden bis Tage vor Erdbeben, Unwetter und Überflutungen. Unruhe, Winseln, Verstecken ohne Ursache. Tierv...

### Wildnis // Tarp-Aufbau & Konfigurationen
*Das vielseitigste Shelter. 6 Grundkonfigurationen. Quellen: Backpacker Wilderness / @greif_xpedition* -- index.html#tarp-aufbau

Der Kanal Backpacker Wilderness setzt konsequent auf Tarp statt Zelt.
- Windrichtung zuerst: Tarp so ausrichten dass die geschlossene Seite in den Wind zeigt, die offene Seite (bei Lean-To) im Windschatten liegt. Windrichtung mit nasser Fingerkuppe bes...
- Wasserabfluss: Leichtes Gefälle unter dem Lager ist besser als flach. Bei Regen sammelt sich Wasser an tiefsten Stellen. Kleinen Graben um Schlafbereich ziehen bei längerem Regen.
- Toter Ast-Check (Widowmaker): Über dem Lager nach toten, hängenden Ästen schauen. Wind und Regen können sie lösen. Keine Ausnahme, auch bei bekannten Bäumen.
- Wasserläufe meiden: Mindestens 50m Abstand zu Bächen und Seen. Feuchtigkeit, Mücken, Überflutungsgefahr bei Regen. Geräusch von Wasser versteckt Geräusche der Umgebung.

### Wildnis // Feuer unter schwierigen Bedingungen
*Regen, Nässe, Wind, Kälte. Wenn es drauf ankommt und es nicht funktioniert.* -- index.html#feuer-bedingungen

Feuer machen wenn alles klatschnass ist, das ist eine Fertigkeit.
- Feuerplattform: Direkt auf Schnee baut kein stabiles Feuer. Trockene Baumrinde oder Äste als Plattform legen bevor das Feuer entzündet wird. Ohne Plattform versinkt das Feuer im sc...
- Stehende Äste nutzen: Liegend auf Schnee ist alles feucht. Stehend toter Ast hat trockenen Kern. Erst brechen, dann spalten, Kern verwenden.
- Harz als Beschleuniger: Kiefer- und Fichtenharz brennt auch nass. Harz an Baumstämmen mit Messer abschaben und unter den Zunder mischen. Kleine Menge reicht.
- Feuerzeug wärmen: Butan-Feuerzeuge versagen unter -5°C. Feuerzeug in der Körperwärme (Hosentasche, Achselhöhle) vorwärmen. Ferro-Stab funktioniert bei jeder Temperatur.

### Wildnis // Signalisierung & Gefunden werden
*Das vergessene Kapitel. Wer sucht, muss gesehen werden. Methoden, Prioritäten, Fehler.* -- index.html#signalisierung

Die meisten Überlebenden werden nicht gefunden weil sie sich durchgeschlagen haben.
- Sie werden gefunden weil jemand sie gesucht hat und sie sichtbar oder hörbar waren.

### L3 // Anbau & Konservierung
*Saatgut anbauen · Haltbarmachen · Krisenökonomie* -- index.html#anbau-konservierung

Saatgut & Anbau Haltbarmachen Tauschhandel L3.11 // Saatgut & Anbau Nahrungsproduktion auch ohne Garten, schnell und einfach Ab Woche 3–4 werden Vorräte knapper.
- Wer frühzeitig mit dem Anbau beginnt, hat in 3–6 Wochen erste Ergebnisse.
- Tag 1: 2–3 EL Linsen/Kichererbsen in Glas, mit Wasser bedecken, 8–12h einweichen.
- Tag 2–5: Wasser abgießen, Glas schräg stellen (luftig, kein Staunasse), 2x täglich mit Wasser spülen und abgießen. Bei Zimmertemperatur.
- Ernte: Wenn Keimlinge 2–4cm, roh essen, kurz braten oder in Suppe. Haltbarkeit im Kühlschrank (wenn vorhanden): 3–5 Tage.
- Geeignetes Saatgut: Linsen, Kichererbsen, Mungbohnen, Weizen, Roggen, Radieschen, Brokkoli. Kaufsaatgut aus dem Supermarkt funktioniert, keine spezielle Keimware nötig.

### Langzeit // Basislager & Langzeitunterschlupf
*Wenn Tage zu Wochen werden. Wochen zu Monaten.* -- index.html#langzeitlager

Ein Basislager in der Wildnis oder in einem verlassenen Gebäude ist kein romantisches Abenteuer.
- Kein sichtbarer Rauch tagsüber: Tagsüber ist Rauch weithin sichtbar. Kochen und Heizen wenn möglich in der Dämmerung oder Nacht. Trockenes Holz erzeugt weniger Rauch als feuchtes. ...
- Keine Lichtquellen nachts nach außen: Licht im Shelter durch Plane, Fell oder dichte Äste abschirmen. Taschenlampen nur mit Rotlichtmodus nach außen. Feuer im Innenbereich halten.
- Keine Pfade zum Lager: Immer auf verschiedenen Wegen zum Lager gehen. Eingetretene Pfade verraten den Standort. Wasser und Holz auf unterschiedlichen Routen holen.
- Geruch managen: Kochen mit Wind im Rücken (Geruch trägt vom Lager weg). Abfall vergraben oder weit entfernt entsorgen. Keine stark riechenden Lebensmittel offen lagern (zieht Tiere...

### Langzeit // Jagd & Nahrungsbeschaffung
*Wenn die 28 Tage vorbei sind. Situationen ohne absehbares Ende.* -- index.html#jagd-nahrung

Jagdausrüstung wie Bogen, Armbrust oder Fallen gehört nicht in den Bug-Out-Bag für die ersten 72 Stunden.
- Beste Jagdzeiten: Dämmerung und erste Dunkelheit (Morgen- und Abenddämmerung). Die meisten Wildtiere sind nacht- oder dämmerungsaktiv. Tagsüber ruhen sie in Deckung.
- Wechsel und Pfade: Wildtiere nutzen immer wieder dieselben Routen zwischen Einstand (Schlaf), Nahrung und Wasser. Spuren im Schlamm, Haare an Ästen, Losung (Kot) zeigen Wechsel an....
- Wasser ist der Magnet: Alle Tiere brauchen Wasser. Bachufer, Tümpel, feuchte Senken sind immer frequentiert. Ansitz am Gewässer bei Dämmerung ist effektiv.
- Wind immer beachten: Tiere wittern. Immer mit dem Wind anpirschen (Wind weht vom Tier zu dir, nicht von dir zum Tier). Geruch ist das wichtigste Sinnesorgan der meisten Wildtiere.

### Langzeit // Druckluftwaffen (PCP)
*Technik · Recht DACH · Ländervergleich · Modelle · Lagerung · Transport · Jagd & Verteidigung · Geschosse* -- index.html#druckluftwaffen-pcp

Grenze des Kapitels: keine Anleitung zu Umbau, Leistungssteigerung oder Export-Kits. Eine F-Waffe über 7,5 Joule ist erlaubnispflichtig. Besitz ohne Erlaubnis ist nach § 52 Abs. 3 Nr. 2 WaffG strafbar (bis drei Jahre Freiheitsstrafe oder Geldstrafe), dazu kann unerlaubtes Bearbeiten kommen (Nr. 3, gleicher Strafrahmen, fahrlässig bis ein Jahr oder Geldstrafe). Händler (GoGun, jabolo) geben an, der Besitz des Export-Kits sei erlaubnisfrei und nur der Einbau brauche eine Erlaubnis (Büchsenmacher, danach WBK). Im Gesetz stehen Ventil, Feder und Hammer nicht in der Liste der wesentlichen Teile (Anlage 1 Nr. 1.3.1), das spricht dafür. Ein Urteil oder eine Behördenauskunft dazu wurde nicht gefunden.
- Technik: PCP speichert Druckluft im Behälter, Ventil gibt pro Schuss eine Luftmenge frei, ein Regler hält den Druck am Ventil konstant. Fülldruck laut Umarex typisch 3.000 bis 4.500 psi (rund 207 bis 310 bar, eigene Umrechnung), maßgeblich ist die Anleitung der Waffe. Handpumpe rund 200 und mehr Hübe, nicht überhitzen. Kompressor mit Feuchtigkeitsabscheider. Für Langzeit gilt: Federdruck (kein Befüllen, weniger Ausfallpunkte) ist robuster, PCP ist ruhiger und präziser, aber abhängig von Luftversorgung und Dichtungen.
- Recht Deutschland: Anlage 2 WaffG Abschnitt 2 Unterabschnitt 2 Nr. 1.1: Druckluft-, Federdruck- und Kaltgaswaffen bis 7,5 J mit F im Fünfeck sind erlaubnisfrei, ab 18. Seit 24.07.2025 (BGBl. I Nr. 171 vom 23.07.2025): Mehrschüssige Waffen, die Geschosse länger als 30 mm verschießen und deren Kennzeichen nicht vor dem 24.07.2025 aufgebracht wurde, sind erlaubnispflichtig. Keine Rückwirkung laut BMI, Altwaffen bleiben frei. Anlass: Hartnadel-Pfeilwaffen. Formulierung gilt als missverständlich (all4shooters). Maßgeblich ist die Geschosslänge und nicht das Kaliber. Rundkugeln und normale Diabolos liegen weit unter 30 mm (eigene Schlussfolgerung, nicht amtlich bestätigt). Kein Modell wird klassifiziert, beim Händler schriftlich bestätigen lassen oder Beschussamt fragen.
- Über 7,5 J: Waffenbesitzkarte, ab 18. Führen zugriffsbereit in der Öffentlichkeit nicht erlaubt (jurawelt, Stand 03.11.2026). Schießen nur auf befriedetem Besitztum, wenn kein Geschoss das Grundstück verlassen kann, oder auf zugelassenen Schießständen. Diabolos sind waffenrechtlich frei. Bußgeldrahmen bis 10.000 € nur aus bussgeldkatalog.net belegt.
- Ausland (Hersteller- und Händlerangaben, nur Orientierung): Österreich § 45 WaffG: Druckluft und CO2 unter 6 mm sind minderwirksame Waffen, keine Joule-Grenze im Gesetz, ab 6 mm Kategorie C. Hersteller LOBO nennt dort 7,5 J und widerspricht damit dem Gesetz (im RIS prüfen). Schweiz (fedpol 2010, möglicherweise veraltet): Waffe ab 7,5 J oder bei Verwechslungsgefahr, Kauf ohne Meldung, Privatimport mit Einfuhrbewilligung. UK rund 12 ft-lb (etwa 16 J), Frankreich 20 J, Spanien rund 24 J, Tschechien 16 J, Polen 17 J, Schweden 10 J, USA keine Bundesgrenze. Mitnahme einer Waffe über 7,5 J nach Deutschland ohne WBK ist unerlaubter Besitz.
- Modelle (nur Herstellerangaben, Preise veraltbar): Huben K1 5,5 mm 19 Schuss bis 350 bar 1.699 €. AEA HPMax Mk2 .35 (9 mm) 8 Schuss max. 300 bar ca. 3 kg 999 €. AEA Megalodon Mk2 F .50 Rubberball (etwa 12,7 mm, unter der 30-mm-Grenze, Sonderregel dürfte nicht greifen) 12 Schuss 250 bis 480 bar ca. 5,4 kg 1.499 €. FX Dreamline Tactical F 4,5 mm 22 Schuss max. 230 bar 2,1 kg. Air Arms S510 Carbine F .177 10 Schuss 190 bar 2,8 kg 1.249 €. Ob ein Modell nach dem 24.07.2025 erlaubnisfrei ist, hängt von Mehrschüssigkeit und Geschosslänge ab.
- Strafen und Urteile: Kein Urteil zum Leistungsumbau gefunden (keine vollständige Recherche in juris oder beck-online). Verstoß gegen die Aufbewahrungspflicht kann nach § 52 Abs. 3 Nr. 7a strafbar sein, wenn Gefahr des Abhandenkommens oder unbefugten Zugriffs entsteht. BGH 3 StR 559/18 (05.02.2019): Besitz eines Luftgewehrs, Einzelstrafe ein Jahr drei Monate, zusammen mit Pistole und Munition Gesamtstrafe drei Jahre zwei Monate, F-Zeichen und Energie unklar, nicht übertragbar. OVG Sachsen 6 B 89/24 (15.01.2025): Laserzielgerät, § 153a StPO gegen 800 Euro, Regelvermutung der Unzuverlässigkeit (§ 5 Abs. 2 Nr. 5 WaffG) mit möglicher Ausnahme, kein Luftdruckfall.
- Lagerung: § 36 Abs. 1 WaffG verlangt erforderliche Vorkehrungen gegen Abhandenkommen und Zugriff Dritter. Tresorpflicht für F-Waffen nicht belegt. Praxis: abschließbarer Schrank oder Koffer, Waffe ungeladen, Diabolos getrennt, Kinder und Gäste ohne Zugriff. Behälter nicht in Sonne oder Hitze, Typenschild und Herstellungsdatum lesen. FEINWERKBAU: Kartuschen 10 Jahre Lebensdauer, ohne Herstellungsdatum nicht mehr nutzen, TÜV verlängert nicht.
- Transport: nicht schussbereit, nicht zugriffsbereit, im verschlossenen Behältnis, mit nachvollziehbarem Anlass, Waffe und Munition getrennt (Polizei NRW, § 12 Abs. 3 Nr. 2 WaffG). Nie unbeaufsichtigt im Fahrzeug lassen.
- Jagd: Jagd ohne Jagdschein ist Wilderei (§ 292 StGB, Primärtext nicht geprüft). § 19 BJagdG erwähnt Luftdruckwaffen nicht, jagdliche Zulassung nicht belegt, Landesrecht möglich. Im absoluten Langzeitkollaps bleibt es formal illegal, Durchsetzung fraglich, keine Freigabe. 7,5 J reichen nach Erfahrungswissen nur für kleinste Beute auf kurze Distanz (nicht geprüft).
- Verteidigung: 7,5 J sind gegen Menschen ungeeignet, Führen verboten, Notwehr (§ 32 StGB, nur paraphrasiert) deckt nur erforderliche Verteidigung gegen gegenwärtigen rechtswidrigen Angriff.
- Geschosse: Diabolos bevorraten. Selbstguss nur im Endzeitszenario, nur Prinzip, keine Rezepte. Bleisicherheit laut Michigan State University: Blei schmilzt bei etwa 327 °C, Dämpfe ab etwa 482 °C, starke Belüftung nach außen, am besten im Freien, nicht essen, trinken oder rauchen, HEPA-Atemschutz, Handschuhe, duschen, Kinder und Frauen im gebärfähigen Alter fernhalten, Staub nicht trocken kehren. BAG, Stiftung Warentest, BfR: kein sicherer Schwellenwert für Blei.
- YouTube (nicht gesichtet, Angaben aus Händler- und Verzeichnisseiten): GoGun ist ein Versandhändler (Essen), AirGhandi ein Testkanal, internationale Kanäle laut Feedspot u. a. AirArmsHuntingSA, Andy's Airgun Reviews, Airguns of Arizona, UpNorthAirGunner. "Big Bore Mike" nicht verifiziert. Viele Videos zeigen in Deutschland nicht legale Leistungen.

### L3 // Heizung, Wärme & Licht
*Heizung ohne Strom · Licht · EMP-Schutz · Offline-Ressourcen* -- index.html#heizung-waerme

Wärme hat in der Krisenvorsorge höchste Priorität, genauso wie Wasser.
- Raum verkleinern: Nur einen kleinen Raum heizen (Innenzimmer bevorzugen, weniger Außenwand). Türen schließen, Rollläden runter, Vorhänge zu.
- Fenster abdichten: Zugluft ist der größte Wärmeverlust. Mit Klebeband, Schaumstoff oder Decken abdichten. Große Fenster mit Folie überkleben.
- Boden isolieren: Kalter Boden zieht Wärme. Teppiche, Decken, Karton auf den Boden legen.
- Körperwärme bündeln: Mehrere Personen in einem kleinen Raum heizen sich gegenseitig. Schlafen in einem Bett spart erheblich Heizenergie.

### L3 // Saisonale Anpassung
*Winter und Sommer verändern fast alles* -- index.html#saisonale-anpassung

Saisonale Vorbereitung ist daher kein Detail, sondern ein eigener Planungsbereich.
- Schneeketten oder Winterreifen, kein Kompromiss
- Camping-Gasheizung (z.B. Mr. Heater) für Innenräume. CO-Warner zwingend!
- Wärmflaschen + Chemische Handwärmer (HeatPaxx)
- Merino-Basisschicht, nass bleibt warm, geruchsneutral

### L3 // Hitzewelle
*Sommerlich, aber lebensbedrohlich. Was wirklich wirkt, was nicht.* -- index.html#hitzewelle

2003 starben in Europa rund 70.000 Menschen [1] , 2022 in Deutschland geschätzt 4.500 Menschen [2] .
- Senioren: Geringes Durstgefühl, schwächere Temperaturregulation. Tägliches Anrufen oder Vorbeischauen, an Trinken erinnern, Wohnung-Check (Außentemperatur vs. Innentemperatur). Sie...
- Säuglinge und Kleinkinder: Höherer Wasserumsatz pro Körpergewicht. NIEMALS allein im Auto lassen, auch nicht "kurz". Innentemperatur kann in 10 Minuten auf 50°C steigen.
- Schwangere: Erhöhter Wasserbedarf, geringere Hitzetoleranz. 3–4 L/Tag, kühlste Räume, keine Anstrengung in Hitze.
- Chronisch Kranke: Diabetes, Herzkreislauf, Nieren, Schilddrüse. Manche Medikamente (Diuretika, Betablocker, Antidepressiva) verstärken die Hitzeempfindlichkeit. Mit Hausarzt vor de...

### L3 // Waldbrand & Starkregen
*Gefahrenindex · Verhalten · Warnstufen · Keller · Rückstau* -- index.html#waldbrand-starkregen

- Waldbrand vorbeugen (BBK-Faltblatt): Saison März bis Oktober, DWD-Gefahrenindex mit fünf Stufen, kein offenes Feuer in und am Wald außer an ausgewiesenen Stellen, nicht rauchen, nicht über trockenem Gras parken, Zufahrten freihalten. Rund 96 Prozent der Waldbrände sind laut WWF menschengemacht.
- Waldbrand entdeckt: erst aus dem Gefahrenbereich, dann 112. Das BBK-Faltblatt rät, sich gegen den Wind in Sicherheit zu bringen. Feuer läuft bergauf schneller, Flugfeuer kann den Weg abschneiden. Beim Notruf Ort (Rettungspunkt-Nummer), Bodenfeuer oder Kronenfeuer, Waldart, Wind und gefährdete Personen nennen. Nur kleine Entstehungsbrände selbst löschen.
- Starkregen laut DWD (12.06.2019): mehr als 25 Liter pro Quadratmeter in einer Stunde ist heftiger Starkregen, mehr als 40 Liter extrem heftig. 40 Liter entsprechen rechnerisch 4 Zentimeter Wasser.
- Verhalten bei Starkregen (Stadt Nürnberg): Keller und Tiefgarage sofort verlassen, vollgelaufene Räume nicht betreten, Strom und Gas abschalten, wenn Überflutung droht, nicht durch überflutete Straßen oder Unterführungen fahren, 112 nur bei akuter Gefahr.
- Haus: Rückstauklappe hält Kanalwasser ab, für genutzte Räume unter Straßenniveau schützt laut Verbraucherzentrale nur eine Hebeanlage ausreichend. Wartung nötig, sonst Versicherungsschutz gefährdet. Heizöltank gegen Aufschwimmen sichern.

### L3 // Naturgefahren
*Lawine, Eisdecke, Starkregen, Waldbrand, Erdbeben. Was im DACH-Raum tatsächlich vorkommt.* -- index.html#naturgefahren

In Deutschland, Österreich und der Schweiz sterben jedes Jahr Menschen an Lawinen, Hochwasser und Eiseinbruch.
- Atmen kontrollieren: Der Kälteschock führt zu Hyperventilation. 1–2 Minuten brauchen, bis ruhiges Atmen möglich wird. In der Zeit am Rand festhalten.
- Richtung Eingangsstelle: Dort war das Eis gerade noch tragfähig. Nicht versuchen, woanders rauszukommen.
- Hochrobben: Mit den Armen flach aufs Eis, schnellste Bewegung mit den Beinen wie beim Schwimmen, dann auf dem Bauch flach wegrollen, nicht aufstehen. Die Last verteilt sich.
- Eispickel oder Schraubenzieher hilft: Wer im Winter auf Eis geht, sollte zwei Spitzen (z.B. Eispicks an Schnur am Hals) griffbereit haben. Wenige Euro, lebensrettend.

### L3 // Krieg & Unruhen
*Verhalten bei militärischen Ereignissen auf deutschem oder europäischem Boden* -- index.html#krieg-unruhen

Dieser Abschnitt ist kein Alarmismus, sondern nüchterne Vorbereitung auf Szenarien die für andere Generationen in Europa Alltag waren.
- NINA-App (BBK): Wichtigste Quelle für offizielle Warnungen in Deutschland. Standortbezogen. Immer installiert und aktiviert lassen. Push-Benachrichtigungen an.
- Warn-App KATWARN: Ergänzung zu NINA, von Versicherern entwickelt, teilweise schneller bei lokalen Ereignissen.
- Rundfunk-Durchsagen: Bei schwerem Krisenfall sendet ARD/ZDF/MDR Durchsagen auch wenn keine App verfügbar. Kurbelradio als Backup.
- Sirenenalarm: Deutschland reaktiviert Sirenennetz (Warntag jeweils zweiter Donnerstag im September). Ein Dauerton bedeutet Entwarnung, Auf-Ab-Ton bedeutet Alarm und Radiohören.

### L3 // Unruhen & Ausschreitungen
*Gekippte Demonstrationen · Plünderungen · Gedränge · Verhalten · Recht · Versicherung* -- index.html#unruhen-ausschreitungen

Am 17. und 18. Oktober 2026 eskalierte in Frankreich ein landesweiter Protesttag (Anlass: Lebenshaltungskosten, Bildungssystem). Behörden meldeten über 2.000 bis rund 2.400 Festnahmen und 600 bis fast 1.000 verletzte Einsatzkräfte. Die Zahlen sind vorläufig und weichen zwischen Meldungen ab (ZDFheute, 18.10.2026).
- Belegt ist eine weltweite Protestwelle 2025/26 (Carnegie Europe und EPD, Juni 2026), Haupttreiber Lebenshaltungskosten. Nicht belegt ist, dass gewaltsame Ausschreitungen in Deutschland zunehmen. Arbeitsannahme: einzelne kurze, lokale Eskalationen, kein Dauerzustand.
- Katastrophe ist nicht Unruhe: Die Befunde zu Desaster-Mythen (Solidarität nach Flut, Stromausfall) gelten für gemeinsam erlittene Notlagen, nicht für Unruhen als sozialen Konflikt.
- Vergleichsfälle: Frankreich 2023 (Tod von Nahel, bis 5.7. laut Bericht 3.625 Festnahmen). Großbritannien 2024 (Southport, Falschbehauptung online, bis 5.9.2024 über 1.280 Festnahmen, 202 Verurteilte). Deutschland Silvester 2023/24 (Berlin rund 390 Festnahmen, 54 verletzte Einsatzkräfte, drei Tote durch selbst gezündete Pyrotechnik).
- Drei Muster (Arbeitsraster, keine amtliche Einteilung): gekippte Großdemo, Auslöser-Unruhen mit Gerüchten als Zündfunke, Anlass-Ausschreitungen wie Silvester.
- Vorher: Aktionstage kennen und die Innenstadt meiden, Basisvorrat (Ziel 28 Tage) reicht, Bargeld, Medikamente, Tank, Gerüchte prüfen. Reise: Hinweise des Auswärtigen Amts lesen, Elefand. Zu Frankreich (Stand 20.10.2026): Demonstrationen meiden, wer unerlaubte gewalttätige Demonstrationen auf Aufforderung nicht verlässt, riskiert Bußgelder und Schadenersatz.
- Im Moment: Früh seitlich aus der Menge gehen, Polizeiaufforderung folgen, nicht mitplündern, brennende Fahrzeuge meiden und 112 rufen. Gedränge: Arme vor der Brust anwinkeln, aufrecht bleiben, der Strömung folgen, Wände und Zäune meiden, nicht fallen, ruhig atmen. Dichte: ohne Körperkontakt unter etwa drei Personen pro Quadratmeter, bei vier bis fünf wird man angerempelt, wenn die Hände kaum beweglich sind, ist die Gefahr akut.
- Reizgas oder Pfefferspray: sofort mit fließendem kaltem Wasser spülen, nicht reiben, Atmung beobachten, bei Atemnot Rettungsdienst 112, bei Asthma oder Bluthochdruck vorsorglich ärztlich abklären. Augenbeschwerden lassen meist nach ein bis mehreren Stunden nach.
- Recht (keine Rechtsberatung): § 125 StGB Landfriedensbruch erfasst Täter oder Teilnehmer an Gewalttätigkeiten aus einer Menge mit vereinten Kräften sowie wer auf die Menge einwirkt, Strafe bis drei Jahre oder Geldstrafe. § 125a: in der Regel besonders schwerer Fall bei Waffe oder gefährlichem Werkzeug, Lebensgefahr, Plündern oder bedeutendem Schaden, sechs Monate bis zehn Jahre. Wer unsicher ist, geht weg. Österreich und Schweiz nicht geprüft.
- Versicherung (Branchenbericht 2018, Bedingungen unterscheiden sich): „Innere Unruhen" ist eng gefasst, Chemnitz 2018 galt als Demonstration. Kasko, Hausrat und Gebäude bei Feuerschäden oft gedeckt, reine Sachbeschädigung an Gebäuden nur mit Vandalismus-Einschluss. Zusatz „innere Unruhen" hatten bei Allianz nur 1,1 Prozent der Privatkunden und 13 Prozent der Firmenkunden. Täter werden oft nicht gefunden, Opferentschädigungsgesetz als möglicher Weg. Eigene Police prüfen.

### L3 // ABC-Schutz. Basiswissen.
*Atomar · Biologisch · Chemisch · Wann handeln · Wann schützen* -- index.html#abc-schutz

Die Wahrscheinlichkeit eines direkten Angriffs ist gering.

### Langzeit // Cyberangriff auf Infrastruktur
*Wenn das Netz nicht ausfällt, sondern gezielt angegriffen wird. Andere Gefahr. Andere Vorbereitung.* -- index.html#cyberangriff

Ein Blackout entsteht durch technisches Versagen.
- Der Unterschied klingt akademisch, ist es aber nicht: Beim Blackout arbeiten alle Behörden sofort an der Reparatur.
- Bargeld sofort abheben: Beim ersten Hinweis auf einen größeren Cyberangriff sofort zum Geldautomaten. Nicht warten bis alle dasselbe tun. Automaten werden schnell leer.
- Keine Panik-Transaktionen: Wenn Banksysteme angegriffen werden, kann man oft noch Bargeld abheben, aber Überweisungen sind unmöglich. Wichtige Zahlungen (Miete, Medikamente) vorher...
- Analoge Kommunikationspunkte: Mit Familie und wichtigen Kontakten heute festlegen: wenn Handys weg sind, treffen wir uns an Ort X um Uhrzeit Y. Klingt altmodisch. Funktioniert wenn...
- Eigene digitale Identität sichern: Wichtige Dokumente (Ausweise, Versicherungen, Kontonummern) analog auf Papier. Nicht nur digital. Wenn Server angegriffen werden, können Datenzen...

### L3 // Blackout-Stufenplan
*Was passiert wann. Stunde 1 bis Woche 4. Was du tust.* -- index.html#blackout-stufenplan

Ein Blackout nach 72 Stunden ist kein Wasser, kein Essen in den Supermärkten, kein Bezahlen, kein Mobilfunk, keine Heizung im Winter und Krankenhäuser am Limit.
- Einkaufen gehen in Stunde 1-2: Der häufigste Fehler. Die Läden sind in 2h leer und das Gedränge ist gefährlich. Wer einen 14-Tage-Vorrat hat, braucht das nicht.
- Dauernd telefonieren: Mobilfunknetz kollabiert wenn alle gleichzeitig anrufen. Akku verschwendet. Kurze SMS, dann Funkstille. Familie weiß durch das Protokoll was zu tun ist.
- Kühlschrank und Tiefkühler öffnen: Jedes Öffnen verkürzt die Haltbarkeit erheblich. Plan machen, was wann entnommen wird -- dann einmal öffnen, nicht zehnmal.
- Kein Wasser sammeln: Die meisten warten bis das Wasser ausfällt. Dann ist es zu spät. In Stunde 0: Badewanne füllen. Das kostet 3 Minuten.

### L3 // Haushalts-Matrix: Was funktioniert wie lange
*Konkrete Stunden- und Tagesangaben pro Gerät* -- index.html#blackout-matrix

In einem Blackout fällt nicht alles sofort aus.
- Manches funktioniert noch Stunden, manches Tage, manches nur mit Einschränkungen.

### L3 // Pandemie & Bio-Bedrohung
*Quarantäne · Schutzausrüstung · Vorräte · Verhalten* -- index.html#pandemie-biobedrohung

Eine hochansteckende, schwere Pandemie kann dramatisch schlimmer sein.

### Wissen // Epidemiologie & Seuchenprävention
*Wie Krankheiten sich ausbreiten. Was die Wissenschaft lehrt. Was im Feld gilt.* -- index.html#epidemiologie-krise

Spanische Grippe 1918: mehr Tote als der gesamte Erste Weltkrieg.
- Isolationsraum: Eigener Raum mit Fenster (Lüftung). Eigene Trinkgefäße und Besteck. Eigene Toilette wenn möglich, sonst eigener Eimer mit Deckel. Pflegeperson wechselt nach Kontakt...
- Quarantänedauer: Immer mind. 2x die Inkubationszeit der verdächtigen Krankheit nach letztem Kontakt. Grippe: 7 Tage. Cholera: 5 Tage. Wenn unklar: 14 Tage ist sicherer Standard.
- Rehydration bei Durchfall: Oral Rehydration Solution (ORS): 1 Liter abgekochtes Wasser, 6 TL Zucker, 0,5 TL Salz. Bei Cholera kann allein diese Lösung die Sterblichkeit von 50% auf...

### L3 // Recht & Gesetze
*Was gilt im Krisenfall. Grundwissen ohne Rechtsberatung* -- index.html#recht-krisenfall

Wer nicht weiß was er darf, gibt Rechte auf.
- § 32 StGB. Notwehr: Wer eine Tat begeht die durch Notwehr geboten ist, handelt nicht rechtswidrig. Notwehr = Verteidigung gegen einen gegenwärtigen rechtswidrigen Angriff.
- Verhältnismäßigkeit: Das Abwehrmittel muss geeignet und erforderlich sein. Kein unverhältnismäßiger Gegeneinsatz, wer mit Fäusten angegriffen wird, darf nicht mit dem Messer reagie...
- Nothilfe: Notwehr gilt auch zum Schutz Dritter, du darfst andere verteidigen.
- Eigenschutz: Flucht ist keine Pflicht, du musst einem Angriff nicht ausweichen wenn Notwehr möglich ist.

### L3 // Drohnen
*Aufklärung · Sicherheitsrisiko · Schutz · Eigener Einsatz* -- index.html#drohnen-schutz

Was 2022 als militärische Besonderheit galt, ist 2025/26 Alltag in hybriden Krisen, zivilen Unruhen und bei Sabotage kritischer Infrastruktur.
- Tarnung und Deckung zuerst: Drohnen-Kameras erkennen Bewegung, Kontrast und Wärme. Stille und Deckung sind die einzig verlässlichen Gegenmaßnahmen. Keine hellen Farben, keine unkon...
- Routinen unterbrechen: Wer jeden Tag um 8h aus dem Haus geht, ist beobachtbar und planbar. In Drohnen-Krisenszenarien: Routinen variieren, Zeitpunkte unvorhersehbar halten.
- OPSEC bei Infrastruktur: Große Vorratslager, Generatoren, Fahrzeugparks sind für Drohnenkameras aus 100m Höhe deutlich sichtbar. Was erkennbar ist, ist angreifbar. Tarnung von Ress...

### L3 // Familiennotfallplan, Senioren & Haustiere
*Treffpunkte · Rollenverteilung · Ausreise ins Ausland* -- index.html#familiennotfallplan

Der Familiennotfallplan muss vor der Krise besprochen, verstanden und geübt werden, nicht improvisiert wenn alle in Panik sind.
- Kontaktperson außerhalb: Eine Vertrauensperson außerhalb der Region als Kommunikations-Hub, alle melden sich bei ihr wenn direkter Kontakt nicht klappt. Oft leichter Ferngespräche ...
- Familien-Codewort: Ein vereinbartes Codewort das signalisiert "echte Notlage, komm sofort": unterscheidet echten Notfall von normaler Kommunikation. Beispiel: "Ich brauche das blau...
- PMR-Kanal: Familienkanal auf PMR-Funk vereinbaren (z.B. Kanal 3, CTCSS 5). Alle Familienmitglieder mit Gerät ausstatten. → Geräteempfehlungen und Frequenzen in L2.03 Kommunikation ...
- SMS bevorzugen: Bei Netzüberlastung kommen SMS oft durch wenn Anrufe scheitern, kleiner Datenpakete, weniger Netz nötig.

### Alltag // Alleinstehende in der Krise
*Was niemand schreibt: wenn man alleine ist.* -- index.html#alleinstehende-krise

Dabei lebt in Deutschland jeder dritte Haushalt als Einpersonenhaushalt.
- Vereinbarung: "Wenn ich mich nicht bis 20:00 Uhr melde, ruf mich an. Keine Antwort: melde es der Polizei oder schau persönlich vorbei."
- Signal statt Anruf: Eine Nachricht reicht. Kein Gespräch nötig. Minimaler Aufwand, maximale Sicherheit.
- Zwei Vertrauenspersonen: Eine nah (Nachbar), eine fern (außerhalb der Krisenregion). Beide kennen das System.
- Schlüssel hinterlegen: Vertrauensperson hat einen Schlüssel. Im Krisenfall kann ohne Einbruch nachgeschaut werden.

### L3 // Gasausfall im Winter
*Wenn das Gas wochenlang weg ist. Heizung, Warmwasser, Kochen, Industrie.* -- index.html#gasausfall-szenario

Ein wochenlanger Gasausfall im Januar ist kein Blackout -- der Strom bleibt meistens an.
- Wasserkocher / Topf auf Herd: 2L kochend in 3 Minuten (Elektroherd). Mit 4L heißem + 4L kaltem hat man 8L warmes Waschwasser auf 35°C.
- Solardusche (Outdoor-Bag): 10-20L schwarzer Wassersack, lädt in der Sonne auf 30-40°C. Im Winter zu schwach -- nur Frühling/Herbst nutzbar.
- Waschen ohne Dusche: Lappen + 2L warmes Wasser pro Person reichen für eine Grundhygiene. Täglich. Trockenshampoo für die Haare.
- Wäsche waschen: Waschmaschine geht (wenn Strom). Aber Wäsche braucht warmes Wasser -- meist Kaltwäsche-Programm verwenden, danach trocknen schwierig (kein Heizen).

### L3 // Solarsturm
*Wenn die Sonne das Stromnetz lahmlegt. Carrington-Szenario.* -- index.html#solarsturm-szenario

Das Carrington-Ereignis 1859 legte Telegrafennetze weltweit lahm, Drähte fingen Feuer.
- Koronaler Massenauswurf (CME): Die Sonne schleudert Milliarden Tonnen geladenes Plasma in den Weltraum. Trifft das die Erde, induziert es Spannungen in langen Leitern (Stromleitung...
- Satelliten ausgefallen: GPS, Wettersatelliten, Kommunikationssatelliten direkt betroffen. Internet-Backbones über Satellitenroute fallen aus. Mobilfunk in vielen Regionen ist nicht...
- Kein EMP-Effekt auf Kleingeräte: Anders als ein nuklearer EMP zerstört ein Solarsturm KEINE Handys, Laptops, Autos. Nur sehr lange Leiter sind betroffen. Faradayscher Käfig hilft a...
- Stecker ziehen: Alle empfindlichen Elektronik vom Netz trennen (PC, TV, Router, Server). Der Solarsturm selbst zerstört Kleinelektronik nicht direkt -- aber Spannungsspitzen im Str...

### L3 // Lieferketten-Ausfall
*Wenn nichts kaputt ist aber trotzdem nichts mehr kommt. Stille Versorgungskrise.* -- index.html#lieferketten-ausfall

Strom läuft, Wasser läuft, Internet läuft.
- Reserve aufbauen: Mit dem Arzt sprechen ob 3-monatige Reserve möglich ist (statt 1-monatig). Apotheker frühzeitig konsultieren. Manche Hausärzte sind kooperativ.
- Wirkstoff statt Marke verstehen: Wenn das Originalpräparat fehlt, sind Generika oft verfügbar. Wirkstoff (z.B. Metformin) auf dem Rezept ist flexibler als Markenname.
- Alternative ausland: In manchen Fällen ist das gleiche Medikament in Österreich oder Schweiz verfügbar, wenn in Deutschland nicht. Mit Arzt und Apotheker sprechen.
- Haltbarkeit: Die meisten Medikamente sind 1-3 Jahre nach Ablauf des MHD noch wirksam (kühl gelagert). Insulin und biologische Präparate sind sensibler. Mit Arzt absprechen.

### L3 // Behinderung & Chronische Erkrankung
*Wenn Standardvorbereitung nicht reicht. Elektromedizin, Mobilität, Kommunikation.* -- index.html#behinderung-krise

Ein Blackout ist für einen mobilen 30-Jährigen unangenehm.
- Verlängerte Autarkie zu Hause: Wenn Rausgehen nicht geht, muss die Wohnung länger versorgen. 14 Tage Wasser und Nahrung sind Minimum, nicht Maximum. Toilette bei Wasserausfall (Che...
- Evakuierungs-Hilfsplan: Wer im Ernstfall dich aus dem Gebäude bringt. Namen und Handynummern greifbar. Feuerwehr informieren dass Person mit Mobilitätseinschränkung im Objekt lebt ...
- Drei-Personen-Regel: Mindestens drei Personen wissen dass du im Ernstfall Hilfe brauchst. Nicht eine. Drei, weil im Ernstfall zwei davon nicht erreichbar sind.
- Pflegedienst-Notfallplan: Wer regelmäßig Pflege bekommt, braucht vom Dienst einen dokumentierten Notfallplan. Wer kommt wann bei welcher Lage? Was, wenn der Pflegedienst selbst aus...

### L3 // Stromabhängige Medizintechnik
*Heimbeatmung · Sauerstoff · Dialyse · Register · Notruf* -- index.html#medizintechnik-strom

- Laut CORRECTIV (26.01.2026) führt keine der abgefragten Kommunen ein Register mit Privatadressen stromabhängiger Menschen. Leipzig nennt bis zu 72 Stunden Eigenverantwortung. Notfallregister.eu (seit Oktober 2022, freiwillig, kostenlos) hat nur wenige Tausend Einträge.
- Heimbeatmung (Merkblatt Stadt Halle): Geräte geladen halten, Ersatzakku oder Ersatzgerät, Beatmungsbeutel für Handbeatmung, stromunabhängige Sauerstoffquelle wie Druckgasflasche, Störungshotline anrufen und Heimbeatmung nennen, wenn möglich in nicht betroffenes Gebiet ausweichen.
- Notruf 112 bei Heimbeatmung: sofort bei Akkuausfall, bei lebensbedrohlicher Lage, früh bei sinkender Akkuspannung und wenn der Stromausfall länger als 2 Stunden dauert.
- Mit Hausarzt, Pflegedienst und Versorger klären, welche Geräte Strom brauchen, wie lange der Akku hält und ob Notstrom nötig ist (AOK, Dezember 2024). Wechseldruckmatratze: normale Schaumstoffmatratze als Ersatz. Kühlpflichtige Medikamente mit Thermometer überwachen.
- Heimdialyse: Notfallplan mit dem Dialysezentrum klären. Powerstation an Medizingeräten nur nach Freigabe durch Hersteller oder Versorger (eigene Einschätzung). Akkulaufzeiten nennen die Quellen nicht.

### L3 // Senioren in der Krise
*Medikamente, Hitze, Sturzrisiko, Hausnotruf, Demenz.* -- index.html#senioren-krise

Krisen treffen Ältere härter, aber nicht wegen des Alters an sich, sondern wegen konkreter, planbarer Faktoren: mehr Dauermedikamente, weniger Durstgefühl, höheres Sturzrisiko im Dunkeln, Abhängigkeit von Technik die Strom braucht.
- Krisen treffen Ältere härter, aber nicht wegen des Alters an sich, sondern wegen konkreter, planbarer Faktoren: mehr Dauermedikamente, weniger Durstgefühl, höheres Sturzrisiko im D...
- Absetzrisiken kennen: Betablocker, Kortison, Antidepressiva und Gerinnungshemmer dürfen nicht abrupt enden. Beim Hausarzt einmal durchgehen: welche meiner Medikamente sind im Engpa...
- Wochendosierer plus Liste: In Stresslagen steigt das Risiko für Doppel- oder vergessene Einnahmen. Ein gefüllter Wochendosierer plus abhakbare Liste kompensiert das, auch für helfe...
- Wohnung nach Hitzewelle-Kapitel kühlen (nachts lüften, tags verdunkeln), aber zusätzlich: den kühlsten Raum der Wohnung identifizieren und die Tagesstruktur dorthin verlegen. Viele...
- Tägliche Kontaktperson während Hitzewellen: Ein fester Anruf pro Tag (Familie, Nachbar). Hitzeschäden entwickeln sich über Stunden bis Tage, Verwirrtheit ist oft das erste sichtbar...

### L3 // Nach der Krise. Zurück in den Alltag.
*Schadensmeldung, Versicherung, psychische Nachwirkungen, Wiederaufbau.* -- index.html#recovery-nachkrise

In den Wochen nach einem Ereignis entscheidet sich, ob du finanziell und psychisch weitgehend heil rauskommst oder ob Fehler in der Nachbereitung teuer werden.
- Fotografieren und filmen, bevor du etwas bewegst. Alle Schäden, aus mehreren Perspektiven, mit Zeitstempel (Handy speichert das automatisch in den Metadaten). Auch beschädigte Elek...
- Weitere Schäden begrenzen. Wasser abstellen, Sicherungen raus, Fenster provisorisch schließen. Das ist gesetzliche Schadensminderungspflicht (§82 VVG), sonst kann die Versicherung ...
- Bei Einbruch oder Diebstahl: sofort zur Polizei. Ohne polizeiliche Anzeige zahlt keine Hausratversicherung. Aktenzeichen aufschreiben, das brauchst du in jeder weiteren Kommunikati...
- Liste beschädigter Gegenstände beginnen. Was kaputt ist, ungefährer Wert, Kaufdatum falls bekannt. Kaufbelege heraussuchen, digitale Rechnungen aus Mailpostfach. Ohne Wertliste kei...

### L3 // Haustier & Nutztier in der Krise
*Futter, Wasser, Medikamente, Transport, Evakuierung.* -- index.html#haustier-krise

In Notunterkünften sind Tiere oft nicht willkommen, Zoohandlungen und Tierärzte fallen bei Blackout und Lieferkettenkrise als erste weg.
- Dauermedikation (Insulin bei Diabetes, Herztabletten bei Herzinsuffizienz, Schilddrüsentabletten): Tierarzt fragen, ob 2-3 Monate Reserve verordnet werden kann. Meist möglich, wenn...
- Impfausweis wasserdicht verpacken. Zusätzlich digitalisieren (Handy-Foto + Cloud). Ohne Impfausweis keine Aufnahme in Tierpensionen, keine Grenzüberquerung, keine Aufnahme in manch...
- Notfallkarte im Fenster oder an der Eingangstür. "Im Haushalt: 2 Katzen (Nala, Simba, chip-reg. bei Tasso), 1 Wellensittich." Rettungskräfte können Tiere im Notfall retten, wenn si...
- Chip-Registrierung aktuell halten. Deutschland: TASSO (kostenlos) und FINDEFIX (Deutscher Tierschutzbund, kostenlos). Bei Umzug oder neuer Telefonnummer sofort aktualisieren.

### Alltag // Sanitär & Toilette
*Toilette · Wasser · Hygiene ohne Infrastruktur* -- index.html#sanitaer-notfall

Wenn Wasser ausfällt, funktioniert die Toilette im Mehrfamilienhaus nicht mehr.

### Alltag // Brand im Gebäude. Was tun.
*Feuer · Rauch · Flucht · Shelter-in-Place* -- index.html#brand-notfall

WICHTIGSTE REGEL: Bei Rauch sofort handeln.
- | Andere warnen hat Vorrang vor allem anderen.

### Alltag // Gasaustritt
*Erdgas · Propangas · Was sofort tun* -- index.html#gasaustritt

Gasgeruch in der Wohnung ist Lebensgefahr.
- Eine Konzentration von nur 4,4 bis 15 Prozent Erdgas in der Luft reicht für eine Explosion.

### Alltag // Krisenküche
*Kochen wenn Stress hoch und Ressourcen knapp sind* -- index.html#krisenkueche

KOHLENMONOXID-GEFAHR: Gaskocher, Holzkohlegrill, Petroleumlampen und Generatoren niemals in Innenräumen oder in der Garage betreiben.
- CO ist farb- und geruchlos und tötet unbemerkt.
- Lagern ohne Kühlung: Sauerteig kann bei Zimmertemperatur durch tägliches Füttern unbegrenzt am Leben gehalten werden. Im Kühlschrank: 1x pro Woche füttern. Auf Reise: zu Pulver tro...
- Warum Sauerteig: Kein Gekauft-Hefe nötig. Haltbarer als Hefebrot. Bessere Bekömmlichkeit. Lange Fermentation baut Phytinsäure ab (Nährstoffaufnahme verbessert).
- Zutaten: 500g Mehl (Type 550 oder Vollkorn), 350ml Wasser, 100g aktiver Sauerteig (oder 7g Trockenhefe + 1 TL Zucker), 10g Salz. Alles verrühren, 30 Min. ruhen lassen, 4-8h gehen l...
- Dutch-Oven vorbereiten: Topf mit Deckel in der Glut vorheizen (ca. 220°C). Teig auf Backpapier geben, in den heißen Topf heben, Deckel drauf. 30 Min. backen. Deckel abnehmen, weite...

### Alltag // Ausrüstung in Schuss halten
*Messer. Beil. Säge. Geschirr. Kleidung. Was kaputt geht wenn man es nicht pflegt.* -- index.html#ausruestungspflege

Das Ergebnis: In einer echten Krise nach einer Woche ist das Messer stumpf, das Geschirr schimmelt, die Kleidung stinkt, die Säge klemmt.
- Nach jedem Gebrauch abwischen: Klinge trocken wischen, sofort. Nicht später. Feuchtigkeit, Säuren aus Lebensmitteln, Blut von Tieren: alles greift Stahl innerhalb von Stunden an. E...
- Schärfen wann: Täglich kurz nachziehen mit dem Keramikstab (10 Sekunden) ist besser als einmal wöchentlich neu schärfen. Wenn das Messer Papier nicht mehr sauber schneidet oder am ...
- Klappmesser und Multitools: Gelenke regelmäßig ölen, besonders nach Regen oder Sand. Einmal im Monat alle Funktionen durchgehen, auf Spiel und Funktion prüfen. Schrauben nachziehen...
- Schneide nach jeder Nutzung: Wie beim Messer: trocken wischen, einölen. Axtklingen aus Kohlenstoffstahl (meistens die guten) rosten schnell. Edelstahlklingen rostresistenter aber n...

### Alltag // Tauschwirtschaft
*Was wirklich Wert hat wenn Geld versagt* -- index.html#bartering

Deutschland 1945-1948, Jugoslawien 1993, Venezuela 2016, Argentinien 2001.
- Stückelung ist alles: Ein 1 oz Goldbarren ist wertlos als Tauschmittel -- niemand kann wechseln. Kleine Münzen (1/10 oz Gold, 1 oz Silber) sind für echten Tausch geeignet.
- Echtheitstest: Magnet (Gold/Silber nicht magnetisch), Ping-Test (echter Klang beim Aufschlagen), Gewicht (Dichte prüfen). Im Zweifel: bekannte Münzen von bekannten Prägeanstalten k...
- Lagerung: Trocken, lichtgeschützt, kühl. Silber in luftdichten Kapseln (oxidiert sonst). Gold unempfindlich. Beides getrennt vom Hauptvorrat lagern -- nicht alles am selben Ort.
- Steuer in Deutschland: Silbermünzen und -barren sind mit 19% MwSt belegt. Goldmünzen und -barren sind MwSt-frei (EU-Regelung). Beim Kauf beachten.

### Alltag // Kinder in der Krise
*Kommunikation · Routine · Altersgerechte Vorbereitung* -- index.html#kinder-krise

Falsch kommuniziert entsteht Panik oder Traumatisierung.
- Analoge Spiele: 2-3 Kartenspiele (Uno, Schwarzer Peter, Quartett), 1-2 Brettspiele (Mensch ärgere dich nicht, Schach/Dame). Kompakt, kein Strom, für alle Altersstufen.
- Papier und Stifte: Ein Block, Bleistifte, Buntstifte. Für Malen, Schreiben, Tagebuch, Notizen. Kostet fast nichts, hält ewig.
- Bücher: 2-3 altersgerechte Bücher pro Kind. Nicht die Lieblinge (die kennen sie auswendig) -- neue, ungelesene. In der Offline-Bibliothek: Kinderklassiker als PDF.
- Trost-Objekte: Kuscheltier, bekannte Decke, Lieblingsbecher. In der Krise sind vertraute Objekte psychologische Anker. Nicht vergessen beim Einpacken.

### Wissen // Mentale Stärke & Erste Hilfe
*Der unterschätzteste Teil jeder Krisenvorsorge. Andere stabilisieren.* -- index.html#mental-staerke

Wer in der Krise in Panik verfällt, macht Fehler.
- Was passiert: Das Gehirn registriert eine Bedrohung und kann sie zunächst nicht einordnen. Die Amygdala (Angstzentrum) übernimmt. Der präfrontale Kortex (rationales Denken) wird he...
- Typische Reaktionen: "Das kann nicht sein." Weitermachen als ob nichts wäre. Auf Bestätigung warten. Keine Entscheidungen treffen können. Körper friert ein (freeze response).
- Was hilft: Atmen. Vier Sekunden ein, vier halten, vier aus (Box Breathing). Aktiviert den Parasympathikus, bremst die Stressreaktion messbar. Drei Wiederholungen reichen für erste ...
- Was nicht hilft: Warten auf Gewissheit. Auf andere hoffen. Gerüchte verfolgen. Im Schock braucht das Gehirn Bewegung, nicht Information.

### Wissen // Körperliche Fitness
*Kein Prepping-Thema wird so oft verschwiegen. Und keines ist so entscheidend.* -- index.html#koerperliche-fitness

Wer nicht 20 kg trägt und 15 km geht, hat den besten BOB umsonst gepackt.
- Körperliche Leistungsfähigkeit ist das Fundament jeder Krisenvorsorge.
- Schuhwerk einlaufen: Wer neue Schuhe kauft und nicht einläuft, bekommt nach 5 km Blasen. Einlaufen: 3x mit zunehmender Distanz tragen bevor sie in den BOB kommen. Das klingt trivia...
- Hitze und Kälte trainieren: Körper an Temperaturextreme gewöhnen. Sommer: Sport in der Mittagshitze. Winter: kurze Einheiten bei Kälte ohne viel Kleidung. Thermoregulation ist trai...
- Schlafentzug simulieren: Einmal im Monat mit 5-6h Schlaf einen vollen Tag durcharbeiten. Kognitive Einbußen kennen und kompensieren lernen. Unangenehm -- aber wertvoll.

### Wissen // Schlaf als Überlebensfaktor
*Der am meisten unterschätzte Aspekt jeder Krise. Wer nicht schläft, macht tödliche Fehler.* -- index.html#schlaf-krise

Jeder kennt das Gefühl nach einer schlechten Nacht.
- Nach 36 Stunden ohne Schlaf entsprechen Reaktionszeit und Entscheidungsqualität einem Promille-Pegel von 1,0.

### Wissen // Offline-Bibliothek
*Was tun wenn Google weg ist. Wissen sichern bevor es gebraucht wird.* -- index.html#offline-bibliothek

Kein Navi, kein Übersetzer, kein Nachschlagen.
- Was er kann: Lokaler Webserver ohne Internet. Alle angeschlossenen Geräte im WLAN können darauf zugreifen. Wikipedia, Karten, Handbücher, Rezepte, Anleitungen -- alles lokal.
- Kosten: Raspberry Pi 4 (ca. 50-80 EUR), 1 TB SSD (ca. 60 EUR), 12V-tauglich. Läuft an Powerbank oder Solarakku.
- Software: KA-Lite (Khan Academy offline), Kiwix-Server (Wikipedia), TileServer GL (OSM-Karten). Einrichtung dauert ca. 2-3 Stunden.
- Alternativer Ansatz: Altes Android-Tablet mit 128+ GB, Kiwix + OsmAnd installiert, dauerhaft geladen halten und im Faraday-Käfig aufbewahren.

### Wissen // Reparieren statt ersetzen
*Die vergessene Fähigkeit. In einer Krise kann man nichts nachkaufen.* -- index.html#reparieren-krise

Wer das nicht beheben kann, hat irgendwann nichts mehr.

### Wissen // Mietrecht & Rechte
*Was Mieter dürfen · Notstandsrecht · Behördenkommunikation* -- index.html#mietrecht-krise

RECHTSHINWEIS: Dieses Kapitel ist eine Orientierung, keine Rechtsberatung.
- Alles schriftlich: Jede Kommunikation mit Vermieter und Behörden schriftlich. Email mit Lesebestätigung. Briefe als Einschreiben. WhatsApp-Nachrichten als Screenshot sichern.
- Fristen kennen: Mängelanzeige sofort. Mietminderung ab dem Zeitpunkt der Anzeige -- nicht rückwirkend.
- Dokumente offline: Mietvertrag, Übergabeprotokoll, gesamter Schriftverkehr offline gesichert. Im Krisenfall sind diese Dokumente oft nicht mehr digital abrufbar.
- Notunterkunft-Anspruch: Wer durch Katastrophe obdachlos wird, hat Anspruch auf Notunterkunft der Gemeinde. Zuständig: Ordnungsamt. Nicht Polizei.

### Zusatz // Arbeit & Arbeitsrecht in der Krise
*Wegerisiko · Betriebsrisiko · Kita zu · Abmahnung* -- index.html#arbeit-krise

- Grundsatz in Deutschland: Der Arbeitnehmer trägt das Wegerisiko, der Arbeitgeber das Betriebsrisiko (IHK Köln, IG Metall).
- Weg blockiert oder Verspätung wegen Wetter: für die ausgefallene Zeit kein Lohn, auch ohne Verschulden. Bei objektiv gefährlichem Weg muss man nicht kommen, bekommt aber keinen Lohn.
- Stromausfall im Betrieb oder Unwetter legt den einzelnen Betrieb lahm: Lohn läuft grundsätzlich weiter. Allgemeine staatliche Schließung wie im Pandemie-Lockdown: laut Bundesarbeitsgericht grundsätzlich kein Lohnanspruch gegen den Arbeitgeber (BAG 5 AZR 366/21 laut IHK Köln).
- Kita oder Schule zu: § 616 BGB kann für einige Tage Lohn sichern, wenn keine andere Betreuung möglich ist. Der Anspruch kann vertraglich oder tariflich ausgeschlossen sein.
- Abmahnung braucht vorwerfbares Verhalten. Bei plötzlichem Ereignis oder amtlicher Unwetterwarnung laut IG Metall nicht gerechtfertigt. Nach etwa drei bis vier Tagen wird erwartet, dass man die Lage einplant.
- Wegeunfall gilt als Arbeitsunfall. Nicht geprüft: kritische Infrastruktur, Pflege, öffentlicher Dienst, Dienstverpflichtung, Österreich, Schweiz. Keine Rechtsberatung.

### Wissen // Warnmeldungen verstehen
*NINA, Cell Broadcast, Sirenen. Was bedeutet was. Was tun in den ersten Minuten.* -- index.html#warnmeldungen

Deutschland hat ein Warnsystem das funktioniert, aber nur wenn man weiß wie es funktioniert.
- Wer beim ersten Sirenenalarm nicht weiß was zu tun ist, verliert wertvolle Minuten.

### Wissen // Desinformation in der Krise
*Gerüchte, Panik-Posts, staatliche Durchsagen. Was stimmt. Wie erkennt man es.* -- index.html#desinformation-krise

Gerüchte verbreiten sich schneller als Fakten.

### Wissen // Gefahrenerkennung
*Was man nicht sehen, riechen oder hören kann. Messgeräte die warnen bevor es zu spät ist.* -- index.html#gefahrenerkennung

Radioaktive Strahlung ist nicht spürbar bis die Schäden entstanden sind.
- Symptome einer CO-Vergiftung: Kopfschmerzen, Übelkeit, Schwindel, Müdigkeit. Oft als Erkältung fehlgedeutet. Bei höheren Konzentrationen: Bewusstlosigkeit, Tod. Heimtückisch: Man f...
- Was beim Alarm: Sofort alle Personen nach draußen. Frische Luft. Nicht zurück bis Ursache gefunden. Notruf 112 wenn jemand Symptome zeigt. Fenster und Türen aufreißen beim Verlasse...
- Empfehlung: X-Sense CO-Melder mit 10-Jahres-Sensor und Display (zeigt CO-Konzentration in ppm an, nicht nur Alarm). Ei Electronics Ei208D als Alternative. Beide EN 50291-zertifizie...
- Wichtigste Eigenschaft: Alarmschwelle einstellbar. Auf 0,30 µSv/h setzen: schlägt an wenn die Strahlung deutlich über Hintergrund steigt, aber keine Fehlalarme durch normale Schwan...

### Wissen // Infrastruktur-Abhängigkeitskarte
*Was hängt wovon ab. Dein persönlicher Ausfall-Durchspieler.* -- index.html#infrastruktur-karte

Die meisten Menschen wissen nicht wie vernetzt ihr Alltag ist, bis etwas ausfällt.
- Dieser Abschnitt macht das Unsichtbare sichtbar: Was verlierst du wenn Strom wegfällt?
- OsmAnd (offline): Wegpunkte für alle relevanten Standorte setzen. Kategorien anlegen (Wasser, Medizin, Versorgung, Sicherheit). Als GPX exportieren und auf USB-Stick sichern.
- Papier-Karte (laminiert): 1:25.000 topografische Karte der Region. Alle wichtigen Punkte einzeichnen. Im BOB. Funktioniert ohne Akku und ohne App.
- Google My Maps: Online-Tool (kostenlos). Eigene Punkte einzeichnen, als KML exportieren, in OsmAnd importieren. Vorab erledigen -- braucht Internet zum Erstellen.

### HW // Was der Staat plant. Was er nicht plant.
*BBK · ESVG · Notbrunnen · Anlaufstellen* -- index.html#staat-planung

Was danach kommt ist dezentral, ereignisabhängig und weniger gut organisiert als die meisten erwarten.
- Zehn Milliarden Euro bis 2029: Das Bundesinnenministerium investiert diese Summe in den Bevölkerungsschutz und die zivile Verteidigung. Das ist ein Vielfaches der bisherigen Mittel...
- Kommando Zivile Verteidigung: Ein neuer Steuerungsstab im BMI/BBK verzahnt militärische und zivile Planung enger, ergänzt um den Ausbau der Zivilen Alarmplanung (ZAP).
- Schutzraumkataster in der NINA-App: Vorhandene Schutzräume werden erfasst und sollen künftig über die Warn-App NINA auffindbar gemacht werden. Das ist für den Einzelnen die konkret...
- Konkrete Beschaffungen: über 1.000 Spezialfahrzeuge, rund 110.000 Feldbetten, zehntausende CBRN-Schutzanzüge, ein THW-Bauprogramm (~3 Mrd. Euro) und der Aufbau der Medizinischen Ta...

### Wissen // Regionale Besonderheiten DACH
*Was in Deutschland, Österreich und der Schweiz anders gilt.* -- index.html#dach-besonderheiten

Die meisten Krisenvorsorge-Ressourcen denken von einem einheitlichen Rechts- und Infrastrukturraum aus.
- Der DACH-Raum ist aber vielfältiger als er aussieht: Was in Deutschland erlaubt ist, kann in der Schweiz anders gehandhabt werden.

### Wissen // Ernährungsbiochemie im Mangel
*Was dem Körper zuerst fehlt. Mangelkrankheiten. Mikronährstoffe im Feld.* -- index.html#ernaehrungs-biochemie

Der Körper braucht neben Energie spezifische Mikronährstoffe: Vitamine, Mineralstoffe und essentielle Fettsäuren.

### Zusatz // Typische Fehler
*Was schiefgeht obwohl man an alles gedacht hat. Aus echter Erfahrung.* -- index.html#typische-fehler

Es sind Fehler die immer wieder passieren, auch bei Leuten die sich ernsthaft vorbereitet haben.

### Zusatz // Üben: der Probelauf
*Tischübung · Abend ohne Strom · Wochenende · Messen · Nachbereitung* -- index.html#probelauf-ueben

- Arbeitsvorschlag von GREIF XPEDITION, keine Behördenempfehlung. Sicherheit geht vor Realismus: Menschen mit strombetriebenen Medizingeräten nehmen am stromlosen Teil nicht teil, Kühlgeräte bleiben am Netz, Flammen nur nach den Regeln der Kapitel zu Heizung und Feldküche.
- Drei Stufen: Tischübung (30 Minuten, Fragen reihum), Abend ohne Strom (3 bis 4 Stunden mit Notkocher und Radio), Wochenende (48 Stunden, Wasser nur aus dem Vorrat, Laden nur aus Powerbank oder Powerstation).
- Messen: Wasser pro Person und Tag, Brauchwasser, Brennstoff pro Mahlzeit, Lampenlaufzeit, Powerstation nach 24 und 48 Stunden, Radioempfang, Stimmung.
- Kleine Übungen: Zehn-Minuten-Packen, fünf Kilometer mit Rucksack, Treffpunkt ohne Navigation ablaufen, zwei Telefonnummern auswendig, Absperrungen für Strom, Gas und Wasser im Dunkeln finden.
- Nachbereitung: drei Lücken aufschreiben und in zwei Wochen schließen, Verbrauchtes ersetzen, zweimal im Jahr wiederholen.

### Zusatz // Krisenvorsorge mit knappem Budget
*Was kaufe ich zuerst. Maximaler Schutz pro Euro.* -- index.html#budget-krisenvorsorge

Krisenvorsorge wird oft als teures Hobby dargestellt.
- Wer 50 EUR im Monat investiert und in der richtigen Reihenfolge vorgeht, ist nach 6 Monaten besser vorbereitet als jemand der 2.000 EUR falsch ausgibt.
- Fertige Krisensets: Teuer, schlecht bestückt, schlechte Qualität. Einzeln kaufen ist immer günstiger und besser angepasst.
- Freeze-Dried-Lebensmittel als Basis: Kosten 5-10x mehr als Supermarkt-Alternativen. Als Ergänzung für BOB ok, als Hauptvorrat für Einsteiger unnötig.
- Teures Outdoor-Equipment: MSR-Kocher für Krisenvorsorge overkill. Ein einfacher BRS-3000T für 8 EUR leistet im Notfall dasselbe. Spezialausrüstung erst wenn Basis steht.
- Alles auf einmal: Besser jeden Monat einen Schritt als einmal 300 EUR falsch ausgeben. Reihenfolge ist wichtiger als Menge.

### Zusatz // Versicherungen & Naturgefahren
*Elementarschutz · Was zahlt was · Pflichten · Schadenfall* -- index.html#versicherungen-krise

- 41 Prozent der Wohngebäude haben laut GDV keinen Elementarschutz (Bericht vom 09.06.2026). Durchschnittlicher versicherter Elementarschaden 2025 rund 4.700 Euro. Pflichtversicherung wird diskutiert, keine Entscheidung genannt.
- Wohngebäude zahlt Sturm, Hagel, Blitz am Haus. Überschwemmung, Starkregen, Rückstau, Erdrutsch, Erdbeben und Schneedruck brauchen den Elementar-Baustein. Hausrat deckt bewegliche Sachen, Überschwemmung nur mit Elementar-Baustein. Teilkasko: abgestelltes Auto bei Überschwemmung oder Hagel. Vollkasko: fahrendes Fahrzeug.
- Details laut Verbraucherzentrale (Stand 31.07.2026): Elementarschutz nur als Zusatz, Sturm ab Windstärke 8, Grundwasser nur versichert, wenn es an die Oberfläche tritt, Rückstau nur mit funktionstüchtiger Rückstausicherung. Sturmflut dort nicht ausdrücklich genannt.
- Pflichten: Rückschlagklappen funktionsfähig, Abflussleitungen frei, Fenster und Türen bei Unwetter zu, Keller abgedichtet. Sonst droht Kürzung.
- Schadenfall: Gefahr beseitigen und Schaden begrenzen, unverzüglich melden, Fotos und Listen, Beschädigtes aufbewahren, Reparaturen erst nach Rücksprache. Bei Streit Versicherungsombudsmann (kostenlos).
- Vorbereitung (eigene Empfehlung): Policen und Hotlines auf Papier, jährlich Räume fotografieren, Selbstbehalt und Wartezeit im Vertrag nachlesen. Österreich und Schweiz nicht geprüft.

### Zusatz // Vollmacht & Patientenverfügung
*Wer entscheidet, wenn du es nicht kannst · Deutschland · Österreich · Schweiz* -- index.html#vorsorgevollmacht

- Häufigster Irrtum: Angehörige dürfen automatisch. In Deutschland dürfen nur Ehegatten und eingetragene Lebenspartner ohne Vollmacht vertreten, nur in Gesundheitsfragen und höchstens sechs Monate (Arzt bestätigt schriftlich). Unverheiratete, Kinder, Eltern nicht. Sonst bestellt das Gericht eine Betreuung.
- Drei Papiere: Vorsorgevollmacht (wer handelt), Betreuungsverfügung (wen das Gericht einsetzen soll), Patientenverfügung (was medizinisch geschehen soll).
- Deutschland: Vorsorgevollmacht schriftlich, Notar grundsätzlich nicht nötig. Beglaubigung der Unterschrift bei der Betreuungsbehörde 10 Euro, nötig für Grundstücksgeschäfte und Erbausschlagung. Notarielle Beurkundung nötig für Darlehensverträge und Unternehmensanteile. Manche Banken wollen eine eigene Bankvollmacht. Lebensgefährliche medizinische Entscheidungen muss die Vollmacht schriftlich und ausdrücklich nennen (Bundesärztekammer).
- Patientenverfügung Deutschland: volljährig, einwilligungsfähig, schriftlich (§ 1827 BGB), bindend wenn sie auf die konkrete Situation passt, jederzeit formlos widerrufbar (BMG, Stand 06.01.2026).
- Zentrales Vorsorgeregister (Bundesnotarkammer): online ab 20,50 Euro. Seit 1. Oktober 2026 auch Inhalte hinterlegbar, lesbar für behandelnde Ärzte und Betreuungsgerichte. Einreichen nur über Betreuungsbehörde oder -verein, Anwalt, Notar. Original bleibt nötig.
- Österreich: Vorsorgevollmacht vor Notar, Rechtsanwalt oder Erwachsenenschutzverein, Registrierung im ÖZVV, wirksam ab Eintragung des Vorsorgefalls. Sonst Erwachsenenvertretung (gewählt, gesetzlich, gerichtlich). Verbindliche Patientenverfügung nur nach ärztlicher Aufklärung, vor Anwalt, Notar, Patientenvertretung oder Erwachsenenschutzverein, gilt acht Jahre. Sonst zu berücksichtigen.
- Schweiz: Vorsorgeauftrag komplett handschriftlich, datiert, unterschrieben oder öffentlich beurkundet, sonst unwirksam. KESB validiert. Ehegatten vertreten in alltäglichen Angelegenheiten. Patientenverfügung schriftlich, datiert, unterzeichnet (Art. 371 ZGB), Hinweis auf der Versichertenkarte möglich.
- Krisenfest (eigene Empfehlung): Kopie in den Notfallordner, Karte im Portemonnaie mit Ansprechpartner, mit Bevollmächtigten vorher reden. Keine Rechtsberatung.

### Zusatz // Szenarien
index.html#szenarien

Was genau tun in Minute 1, Stunde 1, Tag 1 Wissen hilft nichts wenn man in der Krise nicht weiß wo man anfangen soll.
- Diese Entscheidungsbäume geben konkrete Handlungsreihenfolgen, keine Theorie, sondern Schritt für Schritt.

### Quellen & Weiterführendes
*Ausgewählte Quellen -- mit Kommentar warum sie relevant sind.* -- index.html#quellen

Keine vollständige Bibliographie -- sondern eine kuratierte Liste.
- Jede Quelle ist dabei weil sie entweder besonders zuverlässig, besonders tiefgehend oder besonders praktisch ist.
- Twitter/X: @greif_xpedition ↗ (DM oder öffentlich)
- GitHub: github.com/subvrsv/Greif-xpedition ↗ (Issues für Bugs, Pull Requests für Korrekturen)
- Website: greif-xpedition.subvrsv.de ↗

### Zusatz // Shops & Bezugsquellen
*Wo kaufen. Persönliche Empfehlungen, Indie-Läden, Spezialisten.* -- index.html#shops

Es sind Läden und Bezugsquellen die wir kennen, genutzt haben oder die in der Szene einen guten Ruf genießen.

### Checklisten. Bereitschaftsstatus
*Alle Systeme auf einen Blick, interaktiv abhaken* -- index.html#checklist

Der Fortschritt wird im Browser gespeichert.
